function wp_replace_creative_content(creatives_content){
    const wrapper = document.querySelector("#affiliate-portal-content");
    if (wrapper) {
        const customHtml = `
            <div class="custom-creatives-content p-6 wp-test rounded-lg">
                <h1 id="id="social-posts-head"" class="text-3xl font-semibold text-gray-900 mb-5 sm:mb-10">Social Posts</h1>
                <p style="display: none;" class="text-gray-700 mb-6">Here you can copy the social posts.</p>
                <div class="grid gap-6 md:grid-cols-2 lg:grid-cols-3" style="display: flex;flex-direction: column;">
                    ${creatives_content}
                </div>
            </div>
        `;
        wrapper.innerHTML = customHtml;
        // console.log("Social Posts content replaced.");
    } else {
        // console.log("Wrapper element not found.");
    }
}
document.addEventListener("DOMContentLoaded", function () {
    if (window.location.pathname.includes("/affiliate-area/social-posts")) {
        
        // 1?? Change main heading
        const homeHead = document.querySelector("#home-head");
        if (homeHead) {
            homeHead.textContent = "Social Posts";
        }

        // 2?? Replace main wrapper content
        wp_replace_creative_content(creatives_content);
        
        if (document.querySelector('.custom-submissions-content')) {
            let container = document.querySelector('.custom-submissions-content')
                .closest('#affiliate-portal-content');
            if (container) {
                container.removeAttribute('class'); // removes all classes
            }
        }
        
        // 3?? Fix navigation highlighting
        const navItems = document.querySelectorAll(
            ".wp-test-portal-nav-item.bg-gray-900"
        );
        navItems.forEach(item => {
            item.classList.add("text-gray-300","hover:text-white","focus:text-white", "text-gray-300", "hover:bg-gray-700", "focus:bg-gray-700");
            item.classList.remove('bg-gray-900');
        });
        
        // Highlight all links containing "/affiliate-area/social-posts"
        const spLinks = document.querySelectorAll('a[href*="/affiliate-area/social-posts"]');
        spLinks.forEach(link => {
          link.classList.remove('text-gray-300');
          link.classList.add('bg-gray-900', 'text-white');
        });
        
        // Reset any "home" navigation item styles if present
        const homeNavItems = document.querySelectorAll('#home_nav_item');
        homeNavItems.forEach(item => {
          item.classList.remove('bg-gray-900');
          item.classList.add('text-gray-300');
        });


    }
    
    document.addEventListener("click", function(e) {
        
        const copyBtn = e.target.closest('.wp-creative-copy');
        if (copyBtn) {
          const targetClass = copyBtn.getAttribute('data-copy'); // e.g., "wp-creative-copy-5"
          if (targetClass) {
            const targetEl = document.querySelector(`.${targetClass}`);
            if (targetEl) {
                // Extract individual elements
                const nameEl = targetEl.querySelector('.wp-creative-name');
                const textEl = targetEl.querySelector('.wp-creative-text');
                const descriptionEl = targetEl.querySelector('.wp-creative-description');
                const urlEl = targetEl.querySelector('.wp-creative-url span');
                
                // Build formatted text
                let formattedText = '';
                
                if (nameEl) formattedText += nameEl.innerText.trim() + '\n';
                // if (textEl ) formattedText += textEl.innerText.trim() + '\n';
                if ( descriptionEl) formattedText += '\n'+descriptionEl.innerText.trim() + '\n\n';
                if (urlEl) formattedText += 'Visit: ' + urlEl.innerText.trim();
        
              navigator.clipboard.writeText(formattedText).then(() => {
                copyBtn.classList.add('copied');
                const svg = copyBtn.querySelector('svg');
                const span = copyBtn.querySelector('span');
        
                if (svg) svg.style.display = 'none';
                if (span) span.textContent = '🎉 Copied!';
        
                setTimeout(() => {
                  if (svg) svg.style.display = 'inline-block';
                  if (span) {
                    span.textContent = span.classList.contains('wp-clipboard')
                      ? 'Copy To Clipboard'
                      : 'Copy';
                  }
                  copyBtn.classList.remove('copied');
                }, 2000);
              }).catch(err => {
                // console.error('Copy failed:', err);
              });
            }
          }
        }

        const copylink = e.target.closest(".wp-copy-link");
        if (copylink) {
            const btn = copylink.querySelector(".copy-link-btn");
            if (btn) {
                const link = btn.getAttribute("data-link");
                if (link) {
                    navigator.clipboard.writeText(link).then(() => {
                        // console.log("Copied:", link);
                        copylink.classList.add("copied");
                        const svg = copylink.querySelector("svg");
                        const span = copylink.querySelector("span");
        
                        if (svg) svg.style.display = "none";
                        if (span) span.textContent = "🎉 Link copied!";
        
                        setTimeout(() => {
                            if (svg) svg.style.display = "inline-block";
                            if (span) span.textContent = "Copy Link";
                            copylink.classList.remove("copied");
                        }, 2000);
        
                    }).catch(err => {
                        // console.error("Copy failed:", err);
                    });
                }
            }
        }
        
        const sp_popup = e.target.closest(".wp-view-sp-popup");
        if (sp_popup) {
            const wp_sp_popup = sp_popup.closest(".wp-sp-popup-con").querySelector(".wp-popup-modal");
            if (wp_sp_popup) {
                wp_sp_popup.classList.remove("wp-d-none");
                wp_sp_popup.classList.add("wp-opened");
            }
        }
        
        // Existing click handler
        const sp_popup2 = e.target.closest(".wp-hide-popup");
        if (sp_popup2) {
            const wp_opened = sp_popup2.closest(".wp-opened"); // use dot for class
            if (wp_opened) {
                wp_opened.classList.remove("wp-opened");
                wp_opened.classList.add("wp-d-none");
            }
        }
        
        // Escape key handler
        document.addEventListener("keydown", (event) => {
            if (event.key === "Escape") {
                const openedPopup = document.querySelector(".wp-opened");
                if (openedPopup) {
                    openedPopup.classList.remove("wp-opened");
                    openedPopup.classList.add("wp-d-none");
                }
            }
        });


    });


});