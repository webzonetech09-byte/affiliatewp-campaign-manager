    function replace_menu_content(campaign_content){
        const wrapper = document.querySelector("#affiliate-portal-content");
        if (wrapper) {
            const customHtml = `
                <div class="custom-submissions-content p-6 rounded-lg">
                    <h2 class="text-xl font-semibold text-gray-900 mb-4">Submissions</h2>
                    <p class="text-gray-700 mb-6">Here you can manage and track your submissions.</p>
                    <div class="grid gap-6 md:grid-cols-2 lg:grid-cols-3" style="display: flex;flex-direction: column;">
                        ${campaign_content}
                    </div>
                </div>
            `;
            wrapper.innerHTML = customHtml;
            console.log("Submissions content replaced.");
        } else {
            console.log("Wrapper element not found.");
        }
    }
   

    (function () {
        'use strict';

        if (document.getElementById('submissions_nav_item')) return;

        var injected = false;
        var observer = null;

        function buildMenuItem(url) {
            // if (document.getElementById('submissions_nav_item')) {
            //     injected = true;
            //     return null;
            // }

            var a = document.createElement('a');
            a.id = 'submissions_nav_item';
            a.href = url || (window.location.origin + '/affiliate-area/submissions/');
            a.className =
            'mt-1 group px-2 py-2 font-medium rounded-md focus:outline-none transition ease-in-out duration-150 wp-test-portal-nav-item focus:bg-gray-700 text-sm leading-5 text-gray-300 flex items-center';

            a.innerHTML =
            '<svg xmlns="http://www.w3.org/2000/svg" class="mr-3 h-6 w-6 pt-0.5 transition ease-in-out duration-150 text-gray-300 group-focus:text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">' +
            '<path stroke-linecap="round" stroke-linejoin="round" d="M9 17v-6h6v6m-7 4h8a2 2 0 002-2V7a2 2 0 00-2-2H9L5 9v10a2 2 0 002 2z" />' +
            '</svg>' +
            '<span class="wp-nav-label">Submissions</span>';

            return a;
        }
        function buildsocialpostitem(url) {

            var a = document.createElement('a');
            a.id = 'socialpost_nav_item';
            a.href = url || (window.location.origin + '/affiliate-area/social-posts/');
            a.className =
                'mt-1 group px-2 py-2 font-medium rounded-md focus:outline-none transition ease-in-out duration-150 wp-test-portal-nav-item focus:bg-gray-700 text-sm leading-5 text-gray-300 flex items-center';
            a.innerHTML =
                '<svg xmlns="http://www.w3.org/2000/svg" class="mr-3 h-6 w-6 pt-0.5 transition ease-in-out duration-150 text-gray-300 group-focus:text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">' +
                '<path stroke-linecap="round" stroke-linejoin="round" d="M7 8h10m0 0V6a2 2 0 00-2-2H9a2 2 0 00-2 2v2m10 0v8a2 2 0 01-2 2H9a2 2 0 01-2-2v-8m0 0V6a2 2 0 012-2h6a2 2 0 012 2v2M9 12h6m-6 4h6" />' +
                '</svg>' +
                '<span class="wp-nav-label">Social Posts</span>';
            return a;
        }

        function tryInject() {
            if (injected) return;

            // prefer portal container, fallbacks
            var nav = document.querySelector('.wp-testery-nav2') || (document.querySelector('.wp-test-portal-nav-item') && document.querySelector('.wp-test-portal-nav-item').closest('nav')) || document.querySelector('nav') || document.querySelector('#creatives_nav_item');

            if (!nav) return;

            // ensure nav looks like portal nav
            var hasPortalItems = Boolean(nav.querySelector('.wp-test-portal-nav-item') || nav.querySelector('#creatives_nav_item')) || document.querySelector('#creatives_nav_item');
            if (!hasPortalItems) { return; }

            var url = '/affiliate-area/submissions/';
            var item = buildMenuItem(url);
            if (!item) return;
            
            document.querySelectorAll('#creatives_nav_item').forEach((creatives) => {
                creatives.parentNode.insertBefore(item.cloneNode(true), creatives.nextSibling);
            });

            var social_posts = '/affiliate-area/social-posts/';
            var item = buildsocialpostitem(social_posts);
            if (!item) return;
            
            document.querySelectorAll('#creatives_nav_item').forEach((creatives) => {
                creatives.parentNode.insertBefore(item.cloneNode(true), creatives.nextSibling);
            });

            injected = true;
            document.dispatchEvent(new CustomEvent('awce:submissions_added', { detail: { id: 'submissions_nav_item' } }));
            document.dispatchEvent(new CustomEvent('awce:socialpost_added', { detail: { id: 'socialpost_nav_item' } }));
        }

        function startObserverOnceBodyExists() {
            // don't create multiple observers
            if (observer || typeof MutationObserver === 'undefined') return;

            observer = new MutationObserver(function () {
            // stop early if already injected
            if (document.getElementById('submissions_nav_item')) {
                injected = true;
                observer.disconnect();
                return;
            }
            // try injection whenever DOM changes
            tryInject();
            });

            // document.body now exists (this function is called only after that)
            observer.observe(document.body, { childList: true, subtree: true });
        }

        function onReady() {
            tryInject();

            if (document.body) {
            startObserverOnceBodyExists();
            } else {
            // fallback: wait for DOMContentLoaded then start observer
            document.addEventListener('DOMContentLoaded', function () {
                startObserverOnceBodyExists();
            });
            }
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', onReady);
        } else {
            onReady();
        }

        // re-run injection on history navigation
        window.addEventListener('popstate', function () {
            injected = false;
            tryInject();
        });

    })();

    document.addEventListener("DOMContentLoaded", function () {
        if (window.location.pathname.includes("/affiliate-area/submissions")) {
            
            // 1?? Change main heading
            const homeHead = document.querySelector("#home-head");
            if (homeHead) {
                homeHead.textContent = "Submissions";
            }

            // 2?? Replace main wrapper content
            replace_menu_content(campaign_content);
            
            if (document.querySelector('.custom-submissions-content')) {
                let container = document.querySelector('.custom-submissions-content')
                    .closest('#affiliate-portal-content');
                if (container) {
                    container.removeAttribute('class'); // removes all classes
                }
            }
            
            // 3?? Fix navigation highlighting
            const navItems = document.querySelectorAll(
                ".wp-test-portal-nav-item.bg-gray-900"
            );
            navItems.forEach(item => {
                item.classList.add("text-gray-300","hover:text-white","focus:text-white", "text-gray-300", "hover:bg-gray-700", "focus:bg-gray-700");
                item.classList.remove('bg-gray-900');
            });

            // Highlight all links containing "/affiliate-area/submissions"
            const spLinks = document.querySelectorAll('a[href*="/affiliate-area/submissions"]');
            spLinks.forEach(link => {
                link.classList.remove('text-gray-300');
                link.classList.add('bg-gray-900', 'text-white');
            });
        
            // Reset any "home" navigation item styles if present
            const homeNavItems = document.querySelectorAll('#home_nav_item');
            homeNavItems.forEach(item => {
                item.classList.remove('bg-gray-900');
                item.classList.add('text-gray-300');
            });

        }
    });