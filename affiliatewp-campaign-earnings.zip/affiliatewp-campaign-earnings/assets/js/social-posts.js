function wp_replace_creative_content(creatives_content){
    const wrapper = document.querySelector("#affiliate-portal-content");
    if (wrapper) {
        const customHtml = `
            <div class="custom-creatives-content p-6 rounded-lg">
                <h2 class="text-xl font-semibold text-gray-900 mb-4">Creatives</h2>
                <p style="display: none;" class="text-gray-700 mb-6">Here you can copy the creatives.</p>
                <div class="grid gap-6 md:grid-cols-2 lg:grid-cols-3" style="display: flex;flex-direction: column;">
                    ${creatives_content}
                </div>
            </div>
        `;
        wrapper.insertAdjacentHTML('beforeend', customHtml);
        console.log("Sreatives content replaced.");
    } else {
        console.log("Wrapper element not found.");
    }
}
   

(function () {
    'use strict';

    if (document.getElementById('creatives_nav_item')) {
        return;
    }

    var injected = false;
    var observer = null;

    function buildMenuItem(url) {
        if (document.getElementById('creatives_nav_item')) {
        injected = true;
        return null;
        }

        var a = document.createElement('a');
        a.id = 'creatives_nav_item';
        a.href = url || (window.location.origin + '/affiliate-area/submissions/');
        a.className =
        'mt-1 group px-2 py-2 font-medium rounded-md focus:outline-none transition ease-in-out duration-150 wp-test-portal-nav-item focus:bg-gray-700 text-sm leading-5 text-gray-300 flex items-center';

        a.innerHTML =
        '<svg xmlns="http://www.w3.org/2000/svg" class="mr-3 h-6 w-6 pt-0.5 transition ease-in-out duration-150 text-gray-300 group-focus:text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">' +
        '<path stroke-linecap="round" stroke-linejoin="round" d="M9 17v-6h6v6m-7 4h8a2 2 0 002-2V7a2 2 0 00-2-2H9L5 9v10a2 2 0 002 2z" />' +
        '</svg>' +
        '<span class="wp-nav-label">Submissions</span>';

        return a;
    }

    function tryInject() {
        if (injected) return;

        // prefer portal container, fallbacks
        var nav = document.querySelector('.wp-testery-nav2') ||
                (document.querySelector('.wp-test-portal-nav-item') && document.querySelector('.wp-test-portal-nav-item').closest('nav')) ||
                document.querySelector('nav');

        if (!nav) return;

        // ensure nav looks like portal nav
        var hasPortalItems = Boolean(nav.querySelector('.wp-test-portal-nav-item') || nav.querySelector('#creatives_nav_item'));
        if (!hasPortalItems) {
        return;
        }

        var url = (typeof window.awce_data !== 'undefined' && awce_data.submissions_url) ? awce_data.submissions_url : null;
        var item = buildMenuItem(url);
        if (!item) return;

        var creatives = nav.querySelector('#creatives_nav_item');
        if (creatives && creatives.parentNode) {
        creatives.parentNode.insertBefore(item, creatives.nextSibling);
        } else {
        nav.appendChild(item);
        }

        injected = true;
        document.dispatchEvent(new CustomEvent('awce:submissions_added', { detail: { id: 'creatives_nav_item' } }));
    }

    function startObserverOnceBodyExists() {
        // don't create multiple observers
        if (observer || typeof MutationObserver === 'undefined') return;

        observer = new MutationObserver(function () {
        // stop early if already injected
        if (document.getElementById('creatives_nav_item')) {
            injected = true;
            observer.disconnect();
            return;
        }
        // try injection whenever DOM changes
        tryInject();
        });

        // document.body now exists (this function is called only after that)
        observer.observe(document.body, { childList: true, subtree: true });
    }

    function onReady() {
        tryInject();

        if (document.body) {
        startObserverOnceBodyExists();
        } else {
        // fallback: wait for DOMContentLoaded then start observer
        document.addEventListener('DOMContentLoaded', function () {
            startObserverOnceBodyExists();
        });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', onReady);
    } else {
        onReady();
    }

    // re-run injection on history navigation
    window.addEventListener('popstate', function () {
        injected = false;
        tryInject();
    });

})();



document.addEventListener("DOMContentLoaded", function () {
    if (window.location.pathname.includes("/affiliate-area/creatives")) {
        
        // 1?? Change main heading
        const homeHead = document.querySelector("#home-head");
        if (homeHead) {
            homeHead.textContent = "Creatives";
        }

        // 2?? Replace main wrapper content
        wp_replace_creative_content(creatives_content);
        
        if (document.querySelector('.custom-submissions-content')) {
            let container = document.querySelector('.custom-submissions-content')
                .closest('#affiliate-portal-content');
            if (container) {
                container.removeAttribute('class'); // removes all classes
            }
        }
        
        // 3?? Fix navigation highlighting
        const navItems = document.querySelectorAll(
            ".wp-test-portal-nav-item.bg-gray-900"
        );
        navItems.forEach(item => {
            item.classList.add("text-gray-300","hover:text-white","focus:text-white", "text-gray-300", "hover:bg-gray-700", "focus:bg-gray-700");
            item.classList.remove('bg-gray-900');
        });
        
        // Add active styles to Submissions link
        const creativesLink = document.querySelectorAll(
            'a[href*="/affiliate-area/creatives"]'
        );
        if (creativesLink) {
            creativesLink.forEach(creativelink => {
                creativelink.classList.remove("text-gray-300");
                creativelink.classList.add("bg-gray-900", "text-white");
            });

        }

        const homeNav = document.querySelector('#home_nav_item');
        if (homeNav) {
            homeNav.classList.remove('bg-gray-900');
            homeNav.classList.add('text-gray-300');
        }

    }
    
    document.addEventListener("click", function(e) {
        const copyBtn = e.target.closest(".wp-creative-copy");
        if (copyBtn) {
            const targetClass = copyBtn.getAttribute("data-copy"); // e.g. "wp-creative-copy-5"
            if (targetClass) {
                const targetEl = document.querySelector(`.${targetClass}`);
                if (targetEl) {
                    // Get only text content (no HTML tags)
                    const text = targetEl.innerText.trim();
    
                    navigator.clipboard.writeText(text).then(() => {
                        console.log("Copied:", text);
                        
                        // Add copied class
                        copyBtn.classList.add("copied");
    
                        // Find children inside the button
                        const svg = copyBtn.querySelector("svg");
                        const span = copyBtn.querySelector("span");
    
                        if (svg) svg.style.display = "none";
                        if (span) span.textContent = "🎉 Copied!";
                        
                        setTimeout(() => {
                            if (svg) svg.style.display = "inline-block";
                            if (span) {
                                if (span.classList.contains("wp-clipboard")) {
                                    span.textContent = "Copy To Clipboard";
                                } else {
                                    span.textContent = "Copy";
                                }
                            }
                            copyBtn.classList.remove("copied");
                        }, 2000);
    
                    }).catch(err => {
                        console.error("Copy failed:", err);
                    });
                }
            }
        }
        const copylink = e.target.closest(".wp-copy-link");
        if (copylink) {
            const btn = copylink.querySelector(".copy-link-btn");
            if (btn) {
                const link = btn.getAttribute("data-link");
                if (link) {
                    navigator.clipboard.writeText(link).then(() => {
                        console.log("Copied:", link);
                        copylink.classList.add("copied");
                        const svg = copylink.querySelector("svg");
                        const span = copylink.querySelector("span");
        
                        if (svg) svg.style.display = "none";
                        if (span) span.textContent = "🎉 Link copied!";
        
                        setTimeout(() => {
                            if (svg) svg.style.display = "inline-block";
                            if (span) span.textContent = "Copy Link";
                            copylink.classList.remove("copied");
                        }, 2000);
        
                    }).catch(err => {
                        console.error("Copy failed:", err);
                    });
                }
            }
        }
    });


});