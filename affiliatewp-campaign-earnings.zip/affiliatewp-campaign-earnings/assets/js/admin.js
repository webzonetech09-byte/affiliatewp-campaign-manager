jQuery(document).ready(function($){

    $('.delete-campaign-btn').on('click', function(){
        var $btn   = $(this);
        var postId = $btn.data('id');
    
        Swal.fire({
            title: 'Delete this campaign rule?',
            text: 'This action cannot be undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Delete',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: 'Processing...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
    
                $.post(campaignManager.ajax_url, {
                    action: 'delete_campaign_rule',
                    id: postId,
                    nonce: campaignManager.nonce
                }, function(response){
                    Swal.close();
    
                    if (response.success) {
                        $btn.closest('tr').remove(); // remove row
                        var msg = (response.data && response.data.message) ? response.data.message : 'Deleted successfully.';
                        Swal.fire({ title: 'Deleted!', text: msg, icon: 'success' });
                    } else {
                        var msg = (response.data && response.data.message) ? response.data.message : 'Could not delete.';
                        Swal.fire('Error!', msg, 'error');
                    }
    
                }).fail(function(jqXHR){
                    Swal.close();
                    var msg = 'Could not delete.';
                    if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                        msg = jqXHR.responseJSON.message;
                    } else if (jqXHR.responseText) {
                        msg = jqXHR.responseText;
                    }
                    Swal.fire('Error!', msg, 'error');
                });
            }
        });
    });

    jQuery(document).ready(function ($) {
      $(".delete-campaign-btn").on("click", function () {
        var $btn = $(this);
        var typeId = $btn.data("id");

        Swal.fire({
          title: "Delete this campaign type?",
          text: "This action cannot be undone.",
          icon: "warning",
          showCancelButton: true,
          confirmButtonText: "Delete",
          cancelButtonText: "Cancel",
        }).then((result) => {
          if (result.isConfirmed) {
            Swal.fire({
              title: "Processing...",
              allowOutsideClick: false,
              didOpen: () => Swal.showLoading(),
            });

            $.post(
              campaignManager.ajax_url,
              {
                action: "delete_campaign_type", // custom WP AJAX action
                id: typeId,
                nonce: campaignManager.nonce,
              },
              function (response) {
                Swal.close();
                if (response.success) {
                  $btn.closest("tr").remove();
                  Swal.fire(
                    "Deleted!",
                    response.data.message || "Deleted successfully.",
                    "success",
                  );
                } else {
                  Swal.fire(
                    "Error!",
                    response.data.message || "Could not delete.",
                    "error",
                  );
                }
              },
            ).fail(function (jqXHR) {
              Swal.close();
              var msg = "Could not delete.";
              if (jqXHR.responseJSON && jqXHR.responseJSON.message)
                msg = jqXHR.responseJSON.message;
              else if (jqXHR.responseText) msg = jqXHR.responseText;
              Swal.fire("Error!", msg, "error");
            });
          }
        });
      });
    });
    
    // Approve Submission
    jQuery(document).on('click', '.approve-submission', function(){
        var $btn = jQuery(this);
        var postId = $btn.data('id');
        var userId = $btn.data('user_id');
        var membershipId = $btn.data('membership_id');
    
        var status = $btn.closest('tr').find('.status-' + postId).find('span').text().toLowerCase().replace(/\s+/g, '');
        if (status === 'approved') {
            Swal.fire({
                title: 'Already Approved',
                text: 'This submission has already been approved.',
                icon: 'info',
                confirmButtonText: 'OK'
            });
            return;
        }


        // Get remaining limit from hidden input
        var $limitInput = jQuery('#limit-' + userId + '-' + membershipId);
        var postsLeft = parseInt($limitInput.val(), 0);
        
        if (postsLeft <= 0 ) {
            Swal.fire({
                title: 'Limit Reached',
                text: 'No remaining posts are allowed for this membership today.',
                icon: 'warning',
                confirmButtonText: 'OK'
            });
            return;
        }
    
        Swal.fire({
            title: 'Approve this submission?',
            input: 'text',
            inputLabel: 'Reason for approval',
            inputPlaceholder: 'Enter reason here',
            showCancelButton: true,
            confirmButtonText: 'Approve',
            inputValidator: (value) => {
                if (!value) {
                    return 'You must provide a reason for approval!';
                }
                return null;
            }
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({ title: 'Processing...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); } });
                jQuery.post(campaignManager.ajax_url, {
                    action: 'approve_submission',
                    id: postId,
                    reason: result.value,
                    nonce: campaignManager.nonce
                }, function(response){
                    Swal.close();
                    if (response.success) {
                        $btn.closest('tr').find('.status-' + postId).html('<span class="approved status-badge">Approved</span>');
                        $btn.closest('tr').find('.reason-' + postId).html(result.value);
                        $btn.attr('data-status', 'approved');
    
                        // Update hidden input (shared for all buttons of this user+membership)
                        postsLeft--;
                        $limitInput.val(postsLeft);
    
                        Swal.fire({title:'Approved!',text:response.data.message,icon:'success'});
                    } else {
                        Swal.fire('Error!', response.data.message, 'error');
                    }
                }).fail(function(jqXHR){
                    Swal.close();
                    Swal.fire('Error!', jqXHR.responseText || 'Could not approve.', 'error');
                });
            }
        });
    });


    // Reject Submission
    $('.reject-submission').on('click', function(){
        var $btn = $(this);
        var postId = $btn.data('id');

        var status = $btn.closest('tr').find('.status-' + postId).find('span').text().toLowerCase().replace(/\s+/g, '');
        if (status === 'rejected') {
            Swal.fire({
                title: 'Already Rejected',
                text: 'This submission has already been rejected.',
                icon: 'info',
                confirmButtonText: 'OK'
            });
            return;
        }
    
        Swal.fire({
            title: 'Reject this submission?',
            input: 'text',
            inputLabel: 'Reason for rejection',
            inputPlaceholder: 'Enter reason here',
            showCancelButton: true,
            confirmButtonText: 'Reject',
            inputValidator: (value) => {
                if (!value) {
                    return 'You must provide a reason for rejection!';
                }
                return null;
            }
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: 'Processing...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
                $.post(campaignManager.ajax_url, {
                    action: 'reject_submission',
                    id: postId,
                    reason: result.value,
                    nonce: campaignManager.nonce
                }, function(response){
                    Swal.close();
                    $btn.closest('tr').find('.status-' + postId).html('<span class="rejected status-badge">Rejected</span>');
                    $btn.closest('tr').find('.reason-' + postId).html(result.value);
                    $btn.attr('data-status', 'rejected');

                    var msg = '';
                    if (typeof response === 'object' && response !== null && response.data && response.data.message) {
                        msg = response.data.message;
                    } else if (typeof response === 'string') {
                        msg = response;
                    } else {
                        msg = 'Submission has been rejected.';
                    }
                    Swal.fire({title:'Rejected!',text:msg,icon:'error'});
                }).fail(function(jqXHR){
                    Swal.close();
                    var msg = 'Could not reject.';
                    if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                        msg = jqXHR.responseJSON.message;
                    } else if (jqXHR.responseText) {
                        msg = jqXHR.responseText;
                    }
                    Swal.fire('Error!', msg, 'error');
                });
            }
        });
    });
    
    // Edit Campaign
    $('.edit-campaign-btn').on('click', function() {
        var rowId = $(this).data('id');
        var popupContent = $('#edit-form-' + rowId).html();
    
        Swal.fire({
            title: 'Update Membership #' + rowId,
            html: popupContent,
            focusConfirm: false,
            showCancelButton: true,
            confirmButtonText: 'Save Changes',
            customClass: { popup: 'swal2-maxheight-custom' },
            didOpen: () => {
                const popup = document.querySelector('.swal2-popup.swal2-maxheight-custom');
                if (popup) {
                    popup.style.maxHeight = '95vh';
                    popup.style.overflowY = 'auto';
                    popup.style.zIndex = '9999999';
                }
            },
            preConfirm: () => {
                const membershipType = $('#swal2-html-container #membership_type-' + rowId).val()?.trim() || '';
                const amountPerPost  = $('#swal2-html-container #amount_per_post-' + rowId).val()?.trim() || '';
                const postsPerDay    = $('#swal2-html-container #posts_per_day-' + rowId).val()?.trim() || '';
                const limitsApply    = $('#swal2-html-container #limits_apply-' + rowId).is(':checked');
    
                if (!membershipType || !amountPerPost || !postsPerDay) {
                    Swal.showValidationMessage('All fields are required.');
                    return false;
                }
    
                return {
                    id: rowId,
                    membership_type: membershipType,
                    amount_per_post: amountPerPost,
                    posts_per_day: postsPerDay,
                    limits_apply: limitsApply
                };
            }
        }).then((result) => {
            if (!result.isConfirmed) return;
    
            // If checkbox is checked, show confirmation before saving
            if (result.value.limits_apply) {
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'Applying these changes will immediately adjust the user’s limits. Do you want to continue?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, apply limits'
                }).then((confirmResult) => {
                    if (confirmResult.isConfirmed) {
                        processUpdate(result.value);
                    }
                });
            } else {
                processUpdate(result.value);
            }
        });
    
        function processUpdate(values) {
            Swal.fire({ title: 'Processing...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
    
            $.post(campaignManager.ajax_url, {
                action: 'update_earning_row',
                nonce: campaignManager.nonce,
                id: values.id,
                membership_type: values.membership_type,
                amount_per_post: values.amount_per_post,
                posts_per_day: values.posts_per_day,
                limits_apply: values.limits_apply ? 1 : 0
            }, function(response) {
                Swal.close();
                if (response.success) {
                    var tr = $('.edit-campaign-btn[data-id="' + values.id + '"]').closest('tr');
                    tr.find('.membership-' + values.id).text(response.data.membership);
                    tr.find('.amount-' + values.id).text(values.amount_per_post);
                    tr.find('.postsperday-' + values.id).text(values.posts_per_day);
                    $('.wp-ace-datatable').DataTable().row(tr).invalidate().draw(false);
                    $('#posts_per_day-' + values.id).val(values.amount_per_post);
    
                    Swal.fire('Updated!', response.data.message, 'success');
                } else {
                    Swal.fire('Error!', response.data.message || 'Update failed.', 'error');
                }
            }).fail(function(jqXHR) {
                Swal.close();
                var msg = (jqXHR.responseJSON && jqXHR.responseJSON.data && jqXHR.responseJSON.data.message)
                          ? jqXHR.responseJSON.data.message : 'Update failed.';
                Swal.fire('Error!', msg, 'error');
            });
        }
    });

    // Load Creative Info on Edit Page
    const urlParams = new URLSearchParams(window.location.search);
    
    // Check if creative_id parameter exists
    const creativeId = urlParams.get("creative_id");
    
    // If it exists, make AJAX call to fetch creative info
    if (creativeId) {
        console.log("Creative ID from URL:", creativeId);
        jQuery.ajax({
            url: campaignManager.ajax_url, // localized from PHP
            method: "POST",
            data: {
                action: "get_creative_info",
                creative_id: creativeId,
                nonce: campaignManager.nonce
            },
            success: function (response) {
                console.log("AJAX Success:", response);
                $('#affwp_edit_creative #text').val(response.data.creative_text || '');
                console.log("Creative text: ", response.data.creative_text || '');
            },
            error: function (xhr) {
                console.error("AJAX Error:", xhr);
            }
        });
    }

    var $select = $('#affwp_edit_creative .form-table select#type.affwp-use-select2, #affwp_add_creative .form-table select#type.affwp-use-select2');
    if($select.length){
        
        var $chk = $('<p class="wp-checkbox-con"><label><input name="social_post_checkbox" id="social_post_checkbox" type="checkbox" class="wp-custom-social-checkbox" /> Social Post</label></p>');
        if ($('table.form-table').attr('data-current-context') === 'social_post') {
            $('table.form-table').attr('data-current-context', 'text_link');
            $select.val('text_link').trigger('change');
            var $chk = $('<p class="wp-checkbox-con"><label><input name="social_post_checkbox" id="social_post_checkbox" type="checkbox" class="wp-custom-social-checkbox" checked /> Social Post</label></p>');
            $select.add($select.next('.select2')).hide();
        }
        $chk.insertBefore($select);

        $chk.find('input').on('change', function(){
            if(this.checked){
                $select.add($select.next('.select2')).hide();
            } else {
                $select.add($select.next('.select2')).show();
            }
            $('table.form-table').attr('data-current-context','text_link');
            $select.val('text_link').trigger('change');
        });
    }

    var $type = $('table.creatives.affwp-table td.type.column-type a');
    if ( $type.length ) {
        $type.each(function(){
            var text = $(this).text().trim();
            
            if ( text === '' || text === 'social_post' ) {
                $(this).text('Social Post');
            }
        });
    }
    
    var $status_select = $('#affwp_edit_creative .form-table select#status.affwp-use-select2, #affwp_add_creative .form-table select#status.affwp-use-select2');
    
    if ($status_select.length) {
        // ✅ Add default option if none selected
        if ($status_select.find('option[value="social_post"]').length === 0) {
            $status_select.prepend('<option value="social_post" selected>Social Post</option>');
        }
        if (!$status_select.val() || $status_select.val() === '') {
            $status_select.val('social_post').trigger('change');
        }
    }

    var $wp_status = $('table.creatives.affwp-table td.status.column-status span.social_post');
    if ( $wp_status.length ) {
        $wp_status.each(function(){
            $(this).text('Soical Post');
            $(this).addClass('active');
        });
    }
    
});