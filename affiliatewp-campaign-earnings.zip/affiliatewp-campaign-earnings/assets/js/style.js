jQuery(document).ready(function($){

    $('.wp-create-submission').on('click', function(e){
        e.preventDefault();
        var wp_nonce = (typeof campaignManager !== "undefined" && campaignManager.nonce) ? campaignManager.nonce : wp_nonce2;
        var ajax_url = (typeof campaignManager !== "undefined" && campaignManager.ajax_url) ? campaignManager.nonce : ajax_url2;
        var formHtml = `
            <form id="swal-campaign-form" method="post" enctype="multipart/form-data">
                <input type="hidden" name="nonce" value="${wp_nonce}" />
                <input type="hidden" name="action" value="save_campaign" /> <!-- Add this line -->
                <div class="wp-form-field">
                    <label for="link" style="text-align: left;">Submission Link <span class="required">*</span></label>
                    <input type="url" name="submission_link" class="swal2-input update-input" id="submission_link" required placeholder="https://example.com" />
                    <small>Add a link that directs us to the post where you shared our submission links so you can get a reward for it</small>
                </div>

                <div class="wp-form-field">
                    <label for="attachment" style="text-align: left;">Attachment</label>
                    <input type="file" class="swal2-input update-input" name="attachment" id="attachment" accept="image/*,.pdf,.doc,.docx" />
                    <small>Upload Screenshot of shared(optional)</small>
                </div>

                <p class="submit">
                    <input type="submit" name="save_campaign" class="wp-button wp-button-primary" value="Save Submission" />
                    <input type="button" class="button wp-button wp-button-close" value="Cancel" onclick="Swal.close();" />
                </p>
            </form>
        `;
        // alert("ajax_url: " + ajax_url);
        // alert("nonce2: " + wp_nonce);
        Swal.fire({
            title: 'Create New Submission',
            html: formHtml,
            focusConfirm: false,
            showConfirmButton: false,
            customClass: { popup: 'swal2-maxheight-custom' },
            didOpen: () => {
                const popup = document.querySelector('.swal2-popup.swal2-maxheight-custom');
                if (popup) {
                    popup.style.maxHeight = '95vh';
                    popup.style.overflowY = 'auto';
                    popup.style.zIndex = '9999999';
                }

                $('#swal-campaign-form').on('submit', function(ev){
                    ev.preventDefault();
                    Swal.fire({ title:'Processing...', allowOutsideClick:false, didOpen:()=>Swal.showLoading() });

                    var formData = new FormData(this);
                    $.ajax({
                        url: ajax_url,
                        type: 'POST',
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function(response){
                            Swal.close();
                            if(response.success && response.data){
                                Swal.fire('Success!', response.data.message, 'success');
                            } else if(response.data) {
                                Swal.fire('Error!', response.data.message, 'error');
                            }
                        },
                        error: function(){
                            Swal.close();
                            Swal.fire('Error!', 'Failed to save submission.', 'error');
                        }
                    });
                });
            }
        });
    });
});
