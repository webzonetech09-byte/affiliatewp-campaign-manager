jQuery(document).ready(function($){

    $('.delete-submission').on('click', function(){
        var $btn   = $(this);
        var postId = $btn.data('id');
    
        Swal.fire({
            title: 'Delete this submission?',
            text: 'This action cannot be undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Delete',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: 'Processing...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
    
                var wp_nonce = (typeof campaignManager !== "undefined" && campaignManager.nonce) ? campaignManager.nonce : wp_nonce2;
                var ajax_url = (typeof campaignManager !== "undefined" && campaignManager.ajax_url) ? campaignManager.ajax_url : ajax_url2;
    
                $.post(ajax_url, {
                    action: 'delete_submission',
                    id: postId,
                    nonce: wp_nonce
                }, function(response){
                    Swal.close();
    
                    if (response.success) {
                        $btn.closest('tr').remove(); // remove row
                        var msg = (response.data && response.data.message) ? response.data.message : 'Submission has been deleted.';
                        Swal.fire({ title: 'Deleted!', text: msg, icon: 'success' });
                    } else {
                        var msg = (response.data && response.data.message) ? response.data.message : 'Could not delete.';
                        Swal.fire('Error!', msg, 'error');
                    }
    
                }).fail(function(jqXHR){
                    Swal.close();
                    var msg = 'Could not delete.';
                    if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                        msg = jqXHR.responseJSON.message;
                    } else if (jqXHR.responseText) {
                        msg = jqXHR.responseText;
                    }
                    Swal.fire('Error!', msg, 'error');
                });
            }
        });
    });

    // Ensure SweetAlert2 is loaded first
    jQuery(document).on('click', '.wp-submission-attachment', function () {
        var imgUrl = jQuery(this).data('url');
        Swal.fire({
            title: 'Attachment Preview',
            html: '<img src="' + imgUrl + '" style="width:100%; max-width: 500px; max-height:90vh; border-radius:8px;" />',
            showCloseButton: true,
            showConfirmButton: false,
            confirmButtonText: 'Save Changes', // if you want to keep this button
            width: '90%', // Base width control
            customClass: { popup: 'swal2-attachment-popup' },
            didOpen: () => {
                const popup = document.querySelector('.swal2-popup.swal2-attachment-popup');
                if (popup) {
                    popup.style.maxWidth = '600px';
                    popup.style.maxHeight = '90vh';
                    popup.style.overflowY = 'auto';
                    popup.style.zIndex = '99999999999';
                }
            }
        });
    });

    $('.edit-submission-btn').on('click', function(e){
        e.preventDefault();
    
        var $btn = $(this);
        var rowId = $btn.data('id');
        var currentUrl = $btn.data('url'); // get URL from data-url
        var wp_nonce = (typeof campaignManager !== "undefined" && campaignManager.nonce) ? campaignManager.nonce : wp_nonce2;
        var ajax_url = (typeof campaignManager !== "undefined" && campaignManager.ajax_url) ? campaignManager.nonce : ajax_url2;
    
        var formHtml = `
            <form id="swal-edit-form" method="post" enctype="multipart/form-data">
                <input type="hidden" name="nonce" value="${wp_nonce}" />
                <input type="hidden" name="action" value="update_submission" />
                <input type="hidden" name="id" value="${rowId}" />
    
                <div class="wp-form-field">
                    <label for="edit_link">Campaign Link <span class="required">*</span></label>
                    <input type="url" name="submission_link" class="swal2-input update-input" id="edit_link" required placeholder="https://example.com" value="${currentUrl}" />
                    <small>Update the link where you shared our campaign.</small>
                </div>
    
                <div class="wp-form-field">
                    <label for="edit_attachment">Attachment</label>
                    <input type="file" class="swal2-input update-input" name="attachment" id="edit_attachment" accept="image/*,.pdf,.doc,.docx" />
                    <small>Upload a new screenshot (optional)</small>
                </div>
    
                <p class="submit">
                    <input type="submit" name="update_submission" class="wp-button wp-button-primary" value="Save Changes" />
                    <input type="button" class="button wp-button wp-button-close" value="Cancel" onclick="Swal.close();" />
                </p>
            </form>
        `;
    
        Swal.fire({
            title: 'Update Submission #' + rowId,
            html: formHtml,
            focusConfirm: false,
            showConfirmButton: false,
            customClass: { popup: 'swal2-maxheight-custom' },
            didOpen: () => {
                const popup = document.querySelector('.swal2-popup.swal2-maxheight-custom');
                if (popup) {
                    popup.style.maxHeight = '95vh';
                    popup.style.overflowY = 'auto';
                    popup.style.zIndex = '9999999';
                }
    
                $('#swal-edit-form').on('submit', function(ev){
                    ev.preventDefault();
                    Swal.fire({ title:'Processing...', allowOutsideClick:false, didOpen:()=>Swal.showLoading() });
    
                    var formData = new FormData(this);
                    var wp_nonce = (typeof campaignManager !== "undefined" && campaignManager.nonce) ? campaignManager.nonce : wp_nonce2;
                    var ajax_url = (typeof campaignManager !== "undefined" && campaignManager.ajax_url) ? campaignManager.nonce : ajax_url2;

                    $.ajax({
                        url: ajax_url,
                        type: 'POST',
                        nonce: wp_nonce,
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function(response){
                            Swal.close();
                            if(response.success){
                                Swal.fire('Updated!', response.data.message, 'success');
    
                                // Update the URL in the table dynamically
                                var tr = $btn.closest('tr');
                                tr.find('.url-' + rowId).text(formData.get('submission_link'));
    
                                $('.wp-ace-datatable').DataTable().row(tr).invalidate().draw(false);
                            } else {
                                Swal.fire('Error!', response.data.message, 'error');
                            }
                        },
                        error: function(){
                            Swal.close();
                            Swal.fire('Error!', 'Failed to update submission.', 'error');
                        }
                    });
                });
            }
        });
    });

    $('.wp-datatable').DataTable({
        pageLength: 10,
        // order: [[0, 'desc']], // Sort by ID DESC by default
        responsive: true
    });

});