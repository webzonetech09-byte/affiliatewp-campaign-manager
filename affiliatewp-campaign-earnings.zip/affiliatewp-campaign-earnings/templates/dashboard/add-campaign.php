<?php
global $wpdb;
$table_name = $wpdb->prefix . 'affwp_shared_submission';

ob_start();

if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) !== $table_name ) {
    wp_write_logs( 'Table not found: ' . $table_name );
    echo '<div class="error"><p>Errot in fetching data.</p></div>';
    return ob_get_clean();
}

$order_id = get_user_meta( get_current_user_id(), 'employer_package_order_id', true );
$order    = wc_get_order( $order_id );
$have_membership = false;
if ( function_exists( 'wc_memberships_get_user_memberships' ) ) {
    $user_id = get_current_user_id();
    $memberships = wc_memberships_get_user_memberships( $user_id );
    if ( ! empty( $memberships ) ) {
        foreach ( $memberships as $membership ) {
            if ( 'active' === $membership->get_status() ) {
                $have_membership = true;
                break;
            }
        }
    }
}

$show_button = true;
$msg = '';
if ( empty( $have_membership ) ) {
    $msg = '<div class="error"><p>You have not an active membership assigned</p></div>';
    $show_button = false;
} else {
    if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) !== $table_name ) {
        $msg = '<div class="error"><p>Table not found: ' . esc_html( $table_name ) . '</p></div>';
        $show_button = false;
    }
}
?>

<div class="wrap wp-add-form wp-add-campaign">
    <div class="wp-form-con wp-create-submission-con">
        <div class="wr-noti_title">
            <h3 style="font-size: 18px; font-weight: 600;">New Submission</h3>
        </div>

        <?php if ( $show_button ) { ?>
            <div class="create-submission-con">
                <button class="wp-button wp-button-primary wp-create-submission">Create Submission</button>
            </div>
        <?php }else{
            echo $msg;
        } ?>

    </div>
</div>

<?php
return ob_get_clean();
