<?php

global $wpdb;
$table_name = $wpdb->prefix . 'affiliate_wp_creatives'; // wp_affiliate_wp_creatives

ob_start();

// Check if table exists
if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) !== $table_name ) {
    echo '<div class="error"><p>Table not found: ' . esc_html($table_name) . '</p></div>';
    return ob_get_clean();
}

// Fetch rows where type = 'social_post'
$wp_social_post = $wpdb->get_results(
    $wpdb->prepare("SELECT * FROM {$table_name} WHERE status = %s", 'social_post')
);

// Get rows where type != 'social_post' OR NULL
$wp_rows = $wpdb->get_results(
    $wpdb->prepare("SELECT * FROM {$table_name} WHERE status = %s", 'active')
);

?>

<div class="wp-view-creative-content" style="margin-top: 20px">
    <?php
        // echo "<h2 class='text-2xl font-bold mb-5'>Creatives</h2>";
        // echo "<div class='wp-creative-posts grid gap-5 grid-cols-1 mb-10 md:grid-cols-2 lg:grid-cols-4'>";
        // foreach ( $wp_rows as $creative ) {
        //     echo wp_creative_posts_orignal( $creative );
        // }
        // echo "</div>";
        // echo "<h2 class='text-2xl font-bold mb-5'>Social Posts</h2>";
        // echo "<div class='wp-creative-posts grid gap-5 grid-cols-1 mb-10 md:grid-cols-2 lg:grid-cols-4'>";
        // foreach ( $wp_social_post as $creative ) {
        //     echo wp_creative_social_posts( $creative );
        // }
        // echo "</div>";
        // echo "<h2 class='text-2xl font-bold mb-5'>Social Posts Template 2</h2>";
        echo "<div class='wp-creative-posts wp-social-posts'>";
            foreach ( $wp_social_post as $creative ) {
                echo wp_creative_social_posts2( $creative );
            }
        echo "</div>";
    ?>
</div>


<?php
return ob_get_clean();
