<div id="edit-form-<?php echo $id; ?>" class="hidden-popup-content" style="display:none;">
    <input id="amount_per_post-<?php echo $id; ?>" class="swal2-input update-input" type="number" step="0.01" placeholder="Amount per post" value="<?php echo esc_attr($row->amount_per_post); ?>" style="display:block;margin-bottom:8px;">
    <input id="posts_per_day-<?php echo $id; ?>" class="swal2-input update-input" type="number" placeholder="Posts per day" value="<?php echo esc_attr($row->posts_per_day); ?>" style="display:block;margin-bottom:8px;">
</div>