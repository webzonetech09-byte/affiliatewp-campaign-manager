<?php

    global $wpdb;
    $table_name = $wpdb->prefix . 'affwp_shared_submission';

    // Check if table exists
    if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) !== $table_name ) {
        echo '<div class="error"><p>Table not found: ' . esc_html($table_name) . '</p></div>';
        return;
    }
    $rows = $wpdb->get_results("SELECT * FROM $table_name");
    $status_counts = ['pending' => 0, 'approved' => 0, 'rejected' => 0];
    foreach ($rows as $row) {
        $status = strtolower($row->status ?? 'pending');
        if (isset($status_counts[$status])) {
            $status_counts[$status]++;
        }
    }

    $total_count = 0;
    if( $rows ) $total_count = count($rows);


    // $affiliate_portal_settings = affiliate_wp()->settings->get( 'affiliate_portal', array() );
    // echo '<pre>'; print_r($affiliate_portal_settings); echo '</pre>';
	// $menu_links = isset( $affiliate_portal_settings['portal_menu_links'] ) ? $affiliate_portal_settings['portal_menu_links'] : array();
    // echo '<pre>'; print_r($menu_links); echo '</pre>';

    // // Load all AffiliateWP settings
    // $all_settings = get_option( 'affwp_settings', array() );

    // if ( isset( $all_settings['affiliate_portal']['portal_menu_links'] ) ) {

    //     $menu_links = $all_settings['affiliate_portal']['portal_menu_links'];

    //     // The key you used when adding the link
    //     $custom_key = 'custom-support-link';

    //     // If it exists, unset/remove it
    //     if ( isset( $menu_links[ $custom_key ] ) ) {
    //         unset( $menu_links[ $custom_key ] );

    //         // Save back updated links
    //         $all_settings['affiliate_portal']['portal_menu_links'] = $menu_links;
    //         update_option( 'affwp_settings', $all_settings );
    //     }
    // }


    // $affiliate_portal_settings = affiliate_wp()->settings->get( 'affiliate_portal', array() );
    // echo '<pre>'; print_r($affiliate_portal_settings); echo '</pre>';
	// $menu_links = isset( $affiliate_portal_settings['portal_menu_links'] ) ? $affiliate_portal_settings['portal_menu_links'] : array();
    // echo '<pre>'; print_r($menu_links); echo '</pre>';

?>
    <div class="wr-noti_title">
        <h3>Campiagn Earning</h3>
    </div>