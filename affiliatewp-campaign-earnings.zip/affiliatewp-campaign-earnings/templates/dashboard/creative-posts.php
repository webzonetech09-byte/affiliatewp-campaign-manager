<div class="wp-sp-popup-con col-span-1 flex flex-col text-center bg-white rounded-lg shadow creative-card creative-card-<?php echo $id; ?>" data-id="<?php echo $id; ?>">
    <div class="cursor-pointer flex-1 flex p-4 items-center justify-center wp-view-sp-popup">
        <div class="self-center p-4">
            <?php
                // foreach ($creative as $key => $value) {
                //     echo "Key: $key; Value: $value<hr>";
                // }
            ?>
            <?php
                if( $type === 'image' && !empty($image) ) {
                    echo '<img src="'.esc_url($image).'" alt="'.esc_attr($text).'" class="object-scale-down h-48 w-full mx-auto" id="creative_card_creative_card_image" />';
                } else {
                    echo '<p class="underline">'.esc_html($text).'</p>';
                }
            ?>
        </div>
    </div>
    
    <div class="wp-creative-content wp-d-none self-center p-4 wp-creative-content-<?php echo $id; ?>">
        <h2 class="wp-creative-name"><?php echo ucfirst($text); ?></h2>
        <span class="wp-creative-text wp-left"><?php echo $name; ?>:</span>
        <span class="wp-creative-description wp-left"><?php echo $description; ?></span>
        <span class="wp-creative-url wp-left">
            <pre>Visit: <span><?=$url?></span></pre>
        </span>
    </div>

    <div class="border-t border-gray-200">
        <div class="-mt-px flex">
            <div class="w-0 flex-1 flex border-r border-gray-200 wp-view-sp-popup">
                <a class="relative -mr-px flex-1 inline-flex items-center justify-center py-4 text-sm leading-5 text-gray-700 font-medium border border-transparent rounded-bl-lg hover:text-gray-500 focus:outline-none focus:shadow-outline-blue focus:border-blue-300 focus:z-10 transition ease-in-out duration-150 flex items-center"
                    href="#">
                    <svg class="mr-3 h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                    </svg>
                    View
                </a>
            </div>
            <div class="-ml-px w-0 flex-1 flex">
                <button type="button" class="wp-creative-copy py-2 px-4 border border-transparent text-sm leading-5 font-medium rounded-md shadow-sm focus:outline-none focus:shadow-outline-blue transition duration-150 ease-in-out relative -mr-px w-0 flex-1 inline-flex items-center justify-center" data-copy="wp-creative-content-<?php echo $id; ?>">
                    <svg class="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                    </svg>
                    <span class="ml-2" data-copy="wp-creative-content-<?php echo $id; ?>">Copy</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Modal / Preview -->
    <div x-show="open" class="fixed z-10 inset-0 overflow-y-auto wp-popup-modal wp-d-none">
        <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:p-0">
            <div x-show="open" x-transition:enter="ease-out duration-300" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
                    x-transition:leave="ease-in duration-200" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
                    class="fixed inset-0 transition-opacity z-40b" style="display: none;">
                <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen"></span>​
            <div x-show="open" x-transition:enter="ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                    x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100" x-transition:leave="ease-in duration-200" x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
                    x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                    class="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-3/4b sm:p-10 min-w-1/4b"
                    role="dialog" aria-modal="true">
                <div class="absolute top-0 right-0 p-1"><div class="wp-hide-popup flex items-center justify-center h-12 w-12 rounded-full focus:outline-none focus:bg-gray-600 cursor-pointer"><svg id="modal_close" class="h-6 w-6 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></div></div>
                <!-- Description -->
                <div class="mb-5 prose prose-lg2 border-b-2 border-gray-100 pb-3">
                    <p><?php echo $description; ?></p>
                </div>

                <!-- Preview -->
                <div class="creative-preview mb-10">
                    <span class="mb-3 inline-flex items-center px-3 py-1 rounded-md text-sm font-medium leading-5 bg-indigo-100 text-indigo-800">Preview</span>
                    <?php
                        if( $type === 'image' && !empty($image) ) {
                            echo '<img src="'.esc_url($image).'" alt="'.esc_attr($text).'" id="creative_card_creative_modal_image" />';
                        } else {
                            echo '<p class="underline">'.esc_html($text).'</p>';
                        }
                    ?>
                </div>

                <!-- Code -->
                <div class="creative-code">
                    <span class="mb-3 inline-flex items-center px-3 py-1 rounded-md text-sm font-medium leading-5 bg-indigo-100 text-indigo-800">Code</span>
                    <div class="code-block prose">
                        
                    <div class="wp-creative-copy-con">
                        <?php
                            $display_link = esc_html('<a href="' . esc_url($ref_link) . '" title="' . esc_attr($text) . "\">\n" . esc_html($text) . '</a>');
                            if( $type === 'image' && !empty($image) ) {
                                $display_link = esc_html('<a href="' . esc_url($ref_link) . '" title="' . esc_attr($text) . "\">\n" . '<img src="' . esc_url($image) . '" alt="' . esc_attr($text) . '" id="creative_card_creative_modal_image" />' . "\n" . '</a>');
                            }
                            echo $display_link;
                        ?>
                   </div>

                    <div class="mt-5">
                        <span class="inline-flex rounded-md shadow-sm wp-copy-link" data-copy="wp-copy-link-<?php echo $id; ?>">
                            <a class="inline-flex items-center px-4 py-2 border border-transparent text-base leading-6 font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-500 focus:outline-none focus:border-indigo-700 focus:shadow-outline-indigo active:bg-indigo-700 transition ease-in-out duration-150 flex items-center" href="#" id="code_block_copy_to_clipboard">
                                <svg id="code_block_copy_to_clipboard_icon" class="mr-3 h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M7 9a2 2 0 012-2h6a2 2 0 012 2v6a2 2 0 01-2 2H9a2 2 0 01-2-2V9z"></path>
                                    <path d="M5 3a2 2 0 00-2 2v6a2 2 0 002 2V5h8a2 2 0 00-2-2H5z"></path>
                                </svg>
                                <!-- <span class="wp-clipboard">Copy to clipboard</span> -->
                                <span class="wp-clipboard copy-link-btn" data-link="<?php echo esc_html($display_link); ?>">Copy to clipboard</span>

                            </a>
                        </span>
                    </div>
                        
                    </div>
                </div>

            </div>
        </div>
    </div>

</div>