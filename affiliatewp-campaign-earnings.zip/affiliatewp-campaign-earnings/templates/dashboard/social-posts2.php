
<div class="bg-white rounded-lg shadow creative-card creative-card-<?php echo $id; ?>" data-id="<?php echo $id; ?>" @keydown.window.escape="open = false">
    <div class="flex-1 flex p-4 items-center justify-center" @click="open = false">
        <div class="wp-creative-content self-center p-4 wp-creative-content-<?php echo $id; ?>">
            <h2 class="wp-creative-name"><?php echo ucfirst($text); ?></h2>
            <span class="wp-creative-text wp-left"><?php echo $name; ?>:</span>
            <span class="wp-creative-description wp-left"><?php echo $description; ?></span>
            <span class="wp-creative-url wp-left">
                <pre>Visit: <span><?=$url?></span></pre>
            </span>
        </div>
    </div>

    <div class="border-t border-gray-200">
        <div class="-mt-px flex">
            <div class="w-0 flex-1 flex border-r border-gray-200">
                <a class="wp-copy-link relative -mr-px flex-1 inline-flex items-center justify-center py-4 text-sm leading-5 text-gray-700 font-medium border border-transparent rounded-bl-lg hover:text-gray-500 focus:outline-none focus:shadow-outline-blue focus:border-blue-300 focus:z-10 transition ease-in-out duration-150 flex items-center"
                    href="#"
                    @click.prevent="open = false">
                    <!-- <svg class="mr-3 h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                    </svg> View -->
                    <svg class="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                    </svg>
                    <span class="copy-link-btn" data-link="<?=$ref_link?>">Copy Link</span>
                </a>
            </div>
            <div class="-ml-px w-0 flex-1 flex">
                <button type="button" class="wp-creative-copy py-2 px-4 border border-transparent text-sm leading-5 font-medium rounded-md shadow-sm focus:outline-none focus:shadow-outline-blue transition duration-150 ease-in-out relative -mr-px w-0 flex-1 inline-flex items-center justify-center" data-copy="wp-creative-content-<?php echo $id; ?>">
                    <svg class="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                    </svg>
                    <span class="ml-2" data-copy="wp-creative-content-<?php echo $id; ?>">Copy Content</span>
                </button>
            </div>
        </div>
    </div>

</div>