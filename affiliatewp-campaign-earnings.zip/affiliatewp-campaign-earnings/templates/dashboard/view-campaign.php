<?php
    global $wpdb;
    $table_name = $wpdb->prefix . 'affwp_shared_submission';

    ob_start();
    
    // Check if table exists
    if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) !== $table_name ) {
        wp_write_logs( 'Table not found: ' . $table_name );
        echo '<div class="error"><p>Errot in fetching data.</p></div>';
        return ob_get_clean();
    }

    // Fetch saved rules
    $current_user_id = get_current_user_id();

    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM $table_name WHERE user_id = %d ORDER BY id DESC",
            $current_user_id
        )
    );
    
?>

<div class="dashboard-container" style='margin-top: 20px'>
    <div class="wp-form-con wp-table-con">
        <div class="wr-noti_title">
            <h3 style="font-size: 18px; font-weight: 600;">My Submissions</h3>
        </div>
        <div class="table-container">
            <table id="membership-table" class='wp-datatable'>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Link</th>
                        <th>Attachment</th>
                        <th>Submission Date</th>
                        <th>Reason</th>
                        <th>Remark Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="table-body">
                    <?php foreach ($rows as $row) {
                        $status = strtolower($row->status ?? 'pending');
                        $normalizedStatus = $status === 'reject' ? 'rejected' : $status;
                        $id = esc_attr($row->id);
                        $attachment = $row->attachment;
                        $link = $row->link;
                        ?>
                        <tr>
                            <td class="id-<?php echo esc_attr($row->id); ?>"><?php echo esc_html($row->id); ?></td>
                            <td class="link-<?php echo $id; ?>">
                                <a href="<?php echo esc_url($row->link); ?>" target="_blank">
                                    <?php echo esc_html($row->link); ?>
                                </a>
                            </td>
                            <td class="attachment-<?php echo $id; ?>">
                                <?php if (!empty($attachment)): ?>
                                    <img src="<?php echo esc_url($attachment); ?>" data-url="<?=$attachment?>" alt="Attachment" class="wp-submission-attachment wp-submission-<?=$row->id?>" />
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                            <td class="submitted-<?php echo esc_attr($row->id); ?>">
                                <?php echo esc_html( date_i18n( 'd M Y', strtotime( $row->created_at ) ) ); ?>
                            </td>
                            <td class="reason-<?php echo esc_attr($row->id); ?>"><?php echo esc_html($row->reason); ?></td>
                            <td class="remark-<?php echo esc_attr($row->id); ?>">
                                <?php echo esc_html( date_i18n( 'd M Y', strtotime( $row->updated_at ) ) ); ?>
                            </td>
                            <td class="status-<?php echo $id; ?>">
                                <span class="status-badge <?php echo esc_attr($normalizedStatus); ?>">
                                    <?php echo esc_html($normalizedStatus); ?>
                                </span>
                            </td>
                            <td class="action-<?php echo $id; ?>">
                                <div class="action-buttons">
                                    <button class="wp-update wp-approved wp-btn edit-btn edit-submission-btn" data-id="<?php echo $id; ?>" data-url="<?php echo $link; ?>">✎ Edit</button>
                                    <button class="wp-delete wp-rejected wp-btn delete-btn delete-submission" data-id="<?php echo $id; ?>">🗑 Delete</button>
                                </div>
                            </td>

                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php
    return ob_get_clean();