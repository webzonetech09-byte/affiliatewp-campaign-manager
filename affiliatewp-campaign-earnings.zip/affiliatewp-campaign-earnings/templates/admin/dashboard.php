<?php

    global $wpdb;
    $table_name = $wpdb->prefix . 'affwp_shared_submission';

    // Check if table exists
    if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) !== $table_name ) {
        echo '<div class="error"><p>Table not found: ' . esc_html($table_name) . '</p></div>';
        return;
    }
    $rows = $wpdb->get_results("SELECT * FROM $table_name");
    $status_counts = ['pending' => 0, 'approved' => 0, 'rejected' => 0];
    foreach ($rows as $row) {
        $status = strtolower($row->status ?? 'pending');
        if (isset($status_counts[$status])) {
            $status_counts[$status]++;
        }
    }

    $total_count = 0;
    if( $rows ) $total_count = count($rows);
?>
    <div class="dashboard-container">
        <h1 class="dashboard-title">Submissions Statics</h1>
        <div class="status-boxes">
            <div class="status-box total">
                <div class="status-header">
                    <div class="status-icon">Σ</div> <!-- Added icon for Total -->
                    <div class="status-title">Total</div>
                </div>
                <div class="status-count" id="total-count"><?php echo $total_count; ?></div>
                <div class="status-label">All Submissions</div>
            </div>
            <div class="status-box pending">
                <div class="status-header">
                    <div class="status-icon">⏳</div>
                    <div class="status-title">Pending</div>
                </div>
                <div class="status-count" id="pending-count"><?php echo $status_counts['pending']; ?></div>
                <div class="status-label">Awaiting Review</div>
            </div>
            <div class="status-box approved">
                <div class="status-header">
                    <div class="status-icon">✓</div>
                    <div class="status-title">Approved</div>
                </div>
                <div class="status-count" id="approved-count"><?php echo $status_counts['approved']; ?></div>
                <div class="status-label">Active Submissions</div>
            </div>
            <div class="status-box rejected">
                <div class="status-header">
                    <div class="status-icon">✗</div>
                    <div class="status-title">Rejected</div>
                </div>
                <div class="status-count" id="rejected-count"><?php echo $status_counts['rejected']; ?></div>
                <div class="status-label">Declined Submissions</div>
            </div>
        </div>
    </div>