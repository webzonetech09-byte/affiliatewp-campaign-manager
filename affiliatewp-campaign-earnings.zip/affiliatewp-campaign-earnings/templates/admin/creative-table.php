<div class="dashboard-container">
    <div class="data-table">
        <h2 class="table-title" style="display: none;">Membership Applications</h2>
        <div class="table-header">
            <h2 class="table-title">Membership Applications</h2>
        </div>
        <div class="table-container">
            <table id="membership-table" class="wp-datatable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Campaign Type</th>
                        <th>Membership</th>
                        <th>
                            Amount (<?php echo function_exists('get_woocommerce_currency_symbol') ? esc_html(get_woocommerce_currency_symbol()) : '$'; ?>)
                        </th>
                        <th>Posts/day</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="table-body">
                    <?php foreach ($rows as $row): 
                        $status = strtolower($row->status ?? 'pending');
                        $normalizedStatus = $status === 'reject' ? 'rejected' : $status;
                        $id = esc_attr($row->id);

                        $campaign_type = $row->campaign_type;

                        $package_id		 = $row->membership_type;
                        $package_id		 = !empty($package_id) ? intval($package_id) : 0;
                        $product_instant = !empty($package_id)	? get_post( $package_id ) : '';
                        $membership	 = !empty($product_instant) ? sanitize_text_field($product_instant->post_title) : '--';

                    ?>
                    <tr>
                        <td class="id-<?php echo esc_attr($row->id); ?>"><?php echo esc_html($row->id); ?></td>
                        <td class="campaign-<?php echo esc_attr($row->id); ?>" style="text-transform: capitalize;"><?php echo esc_html($campaign_type); ?></td>
                        <td class="membership-<?php echo esc_attr($row->id); ?>" style="text-transform: capitalize;"><?php echo esc_html($membership); ?></td>
                        <td class="amount-<?php echo esc_attr($row->id); ?>"><?php echo esc_html($row->amount_per_post); ?></td>
                        <td class="postsperday-<?php echo esc_attr($row->id); ?>"><?php echo esc_html($row->posts_per_day); ?></td>
                        <td class="action-<?php echo $id; ?>">
                            <div class="action-buttons">
                                <button class="wp-update btn edit-btn edit-campaign-btn" data-id="<?php echo $id; ?>" > ✎ Edit </button>
                                <button class="wp-delete btn delete-btn delete-campaign-btn" data-id="<?php echo $id; ?>">🗑 Delete</button>
                            </div>
                        </td>

                    </tr>
                    <?php
                        include( AFFWP_CAMPAIGN_ADMIN_PATH.'edit-campaign.php' );
                        endforeach;
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>