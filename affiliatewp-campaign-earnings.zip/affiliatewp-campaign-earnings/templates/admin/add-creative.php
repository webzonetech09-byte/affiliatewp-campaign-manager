<?php
    global $wpdb;
    $table_name = $wpdb->prefix . 'affwp_creative_earnings_settings';

    // Check if table exists
    if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) !== $table_name ) {
        echo '<div class="error"><p>Table not found: ' . esc_html($table_name) . '</p></div>';
        return;
    }
    // Handle form submission
    if ( isset($_POST['save_earning']) ) {
        $result = $wpdb->insert( $table_name, [
            'campaign_type' => sanitize_text_field($_POST['campaign_type']),
            'membership_type' => sanitize_text_field($_POST['membership_type']),
            'amount_per_post' => floatval($_POST['amount_per_post']),
            'posts_per_day'   => intval($_POST['posts_per_day']),
        ] );
        if ( $result ) {
            echo '<div class="updated"><p>Saved successfully!</p></div>';
        } else {
            echo '<div class="error"><p>Save failed!</p></div>';
        }
    }
?>
<div class="wrap wp-add-form">
    <h2 style="display: none">New Freelancer Rule</h2>
    <div class="wp-form-con wp-add-creative">
        <h2>New Freelancer Rule</h2>
        <form method="post">

        <div class="wp-form-field">
            <label for="campaign_type">Campaign Type</label>
            <select name="campaign_type" id="campaign_type">
                <?php 
                $types = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}affwp_campaign_types");
                // $types = get_option('cm_campaign_types', []);
                echo '<option value="">-- Select Campaign Type --</option>';
                foreach($types as $type) {
                    echo '<option value="'.$type->id.'">'.$type->type_name.'</option>';
                }
                ?>
            </select>
        </div>

            <div class="wp-form-field">
                <label for="membership_type">Membership Type</label>
                <select name="membership_type" id="membership_type">
                    <option value="">-- Select Membership Plan --</option>
                    <?php
                        echo do_shortcode('[membership_dropdown]')
                    ?>
                </select>
            </div>
            
            <div class="wp-form-field">
                <label for="amount_per_post">Amount per Post</label>
                <input type="number" name="amount_per_post" id="amount_per_post" step="0.01" value="" required />
            </div>
            
            <div class="wp-form-field">
                <label for="posts_per_day">Posts per Day</label>
                <input type="number" name="posts_per_day" id="posts_per_day" value="" required />
            </div>
            
            <p><input type="submit" name="save_earning" class="wp-button wp-button-primary" value="Save"></p>
        </form>
    </div>
</div>