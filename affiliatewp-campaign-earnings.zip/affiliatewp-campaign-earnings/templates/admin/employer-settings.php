<?php

    if(isset($_POST['save_emp_settings'])) {
        update_option('buzz_employer_home_link', esc_url($_POST['employer_home_link']));
        echo '<div class="updated"><p>Settings Saved.</p></div>';
    }
    $link = get_option('buzz_employer_home_link', '');
    ?>
    <div class="wrap">
        <h1>Employer Settings</h1>
        <form method="post">
            <label>Social Buzz Employer-Home Link:</label>
            <input type="text" name="employer_home_link" value="<?php echo $link; ?>" class="regular-text">
            <?php submit_button('Save Settings', 'primary', 'save_emp_settings'); ?>
        </form>
    </div>
    <?php
