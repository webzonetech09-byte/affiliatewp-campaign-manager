<?php
global $wpdb;
$table_name = $wpdb->prefix . 'affwp_campaign_types'; // your custom table

// Handle Add
if ( isset($_POST['add_campaign_type']) ) {

    $type_name = sanitize_text_field($_POST['type_name']);

    if (!empty($type_name)) {

        // Check if it already exists
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE type_name = %s",
            $type_name
        ));

        if (!$exists) {
            $wpdb->insert(
                $table_name,
                [ 'type_name' => $type_name, 'created_at' => current_time('mysql') ],
                [ '%s', '%s' ]
            );
            echo '<div class="updated"><p>Campaign Type Added Successfully!</p></div>';
        } else {
            echo '<div class="error"><p>This Campaign Type already exists!</p></div>';
        }

    } else {
        echo '<div class="error"><p>Campaign Type cannot be empty!</p></div>';
    }
}

// Fetch all types
$types = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY id ASC" );
?>

<!-- ADD FORM -->
<div class="wrap wp-add-form">
    <div class="wp-form-con wp-add-creative">
        <h2>Add Campaign Type</h2>

        <form method="post">
            <div class="wp-form-field">
                <label for="type_name">Campaign Type Name</label>
                <input type="text" name="type_name" id="type_name" required />
            </div>

            <p>
                <input type="submit" 
                       name="add_campaign_type" 
                       class="wp-button wp-button-primary" 
                       value="Save">
            </p>
        </form>
    </div>
</div>

<!-- TABLE UI -->
<div class="dashboard-container">
    <div class="data-table">
        <div class="table-header">
            <h2 class="table-title">Campaign Types</h2>
        </div>

        <div class="table-container">
            <table class="wp-datatable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Campaign Type</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (!empty($types)) : ?>
                        <?php foreach ($types as $index => $type): ?>
                            <tr>
                                <td><?php echo esc_html($index + 1); ?></td>

                                <td class="type-<?php echo esc_attr($type->id); ?>">
                                    <?php echo esc_html($type->type_name); ?>
                                </td>

                                <td>
                                    <div class="action-buttons">
<button class="wp-delete btn delete-campaign-btn" 
        data-id="<?php echo esc_attr($type->id); ?>">
    🗑 Delete
</button>                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="3">No Campaign Types Found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>
    </div>
</div>