<div id="edit-form-<?php echo $id; ?>" class="hidden-popup-content" style="display:none;">
<div class="wp-form-field">
    <label for="campaign_type">Campaign Type</label>
    <select name="campaign_type" id="campaign_type">
        <?php 
        $types = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}affwp_campaign_types");
        foreach($types as $type) {
            echo '<option value="'.$type->id.'">'.$type->type_name.'</option>';
        }
        ?>
    </select>
</div>
    <select id="membership_type-<?php echo $id; ?>" class="swal2-input update-select" style="display:block;margin-bottom:8px;">
        <?php echo do_shortcode('[membership_dropdown]'); ?>
    </select>
    <input id="amount_per_post-<?php echo $id; ?>" class="swal2-input update-input" type="number" step="0.01" placeholder="Amount per post" value="<?php echo esc_attr($row->amount_per_post); ?>" style="display:block;margin-bottom:8px;">
    <input id="posts_per_day-<?php echo $id; ?>" class="swal2-input update-input" type="number" placeholder="Posts per day" value="<?php echo esc_attr($row->posts_per_day); ?>" style="display:block;margin-bottom:8px;">
    <label style="display:block;margin-top:10px; text-align: left;">
        <input type="checkbox" id="limits_apply-<?php echo $id; ?>"> Limits will apply now
    </label>
</div>
