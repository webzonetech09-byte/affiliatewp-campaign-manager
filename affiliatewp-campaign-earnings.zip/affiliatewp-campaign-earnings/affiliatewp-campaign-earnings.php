<?php
/**
 * Plugin Name: AffiliateWP Campaign Earnings
 * Description: Adds Long Text creatives and Campaign Earnings functionality to AffiliateWP
 * Version: 1.0.0
 * Author: Rana Sattar
 * Author URI: https://fiverr.com/ranasattar
 * License: GPL-2.0+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ACE
 * Domain Path: /languages
 */

if(isset($_GET['sattar'])){
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);   
}


    // Prevent direct access
    if (!defined('ABSPATH')) exit;
    if (!defined('AFFWP_CAMPAIGN_VERSION')) define('AFFWP_CAMPAIGN_VERSION', '1.0.0');
    if (!defined('AFFWP_CAMPAIGN_PLUGIN_DIR')) define('AFFWP_CAMPAIGN_PLUGIN_DIR', plugin_dir_path(__FILE__));
    if (!defined('AFFWP_CAMPAIGN_PLUGIN_URL')) define('AFFWP_CAMPAIGN_PLUGIN_URL', plugin_dir_url(__FILE__));
    if( !defined('WP_LOGS_FILE') ) define('WP_LOGS_FILE', plugin_dir_path(__FILE__).'wp-logs.txt');

    if (!defined('AFFWP_CAMPAIGN_PUBLIC_PATH')) define('AFFWP_CAMPAIGN_PUBLIC_PATH', AFFWP_CAMPAIGN_PLUGIN_DIR.'public/');
    if (!defined('AFFWP_CAMPAIGN_INC_PATH')) define('AFFWP_CAMPAIGN_INC_PATH', AFFWP_CAMPAIGN_PLUGIN_DIR.'inc/');

    if (!defined('AFFWP_CAMPAIGN_TEMP_PATH')) define('AFFWP_CAMPAIGN_TEMP_PATH', AFFWP_CAMPAIGN_PLUGIN_DIR.'templates/');
    if (!defined('AFFWP_CAMPAIGN_ADMIN_PATH')) define('AFFWP_CAMPAIGN_ADMIN_PATH', AFFWP_CAMPAIGN_TEMP_PATH.'admin/');
    if (!defined('AFFWP_CAMPAIGN_DASH_PATH')) define('AFFWP_CAMPAIGN_DASH_PATH', AFFWP_CAMPAIGN_TEMP_PATH.'dashboard/');

    if (!defined('AFFWP_CAMPAIGN_ASSETS_URL')) define('AFFWP_CAMPAIGN_ASSETS_URL', AFFWP_CAMPAIGN_PLUGIN_URL.'assets/');
    if (!defined('AFFWP_CAMPAIGN_CSS_URL')) define('AFFWP_CAMPAIGN_CSS_URL', AFFWP_CAMPAIGN_ASSETS_URL.'css/');
    if (!defined('AFFWP_CAMPAIGN_JS_URL')) define('AFFWP_CAMPAIGN_JS_URL', AFFWP_CAMPAIGN_ASSETS_URL.'js/');


    require_once(AFFWP_CAMPAIGN_INC_PATH.'wp-logs.php');
    require_once(AFFWP_CAMPAIGN_INC_PATH.'ajax-manager.php');
    require_once(AFFWP_CAMPAIGN_INC_PATH.'wp-tables.php');
    require_once(AFFWP_CAMPAIGN_INC_PATH.'functions.php');
    require_once(AFFWP_CAMPAIGN_INC_PATH.'controller.php');
    // require_once(AFFWP_CAMPAIGN_PUBLIC_PATH.'class-header.php');
    // require_once('admin-dashboard/class-admin-dashboard.php');
    
    
    require_once __DIR__ . '/includes/class-portal.php';
    
    register_activation_hook( __FILE__, function() {
        ace_create_wp_tables();
    });
    