<?php 
// Do NOT use the AffiliateWP namespace here, keep your plugin code in its own namespace
// namespace AffiliateWP_Campaign_Earnings;
// use AffiliateWP_Affiliate_Portal\Core\Components\Portal;

// Register custom endpoint: /affiliate-area/submissions/
function wpace_register_rewrite_endpoints() {
    add_rewrite_endpoint( 'submissions', EP_ROOT | EP_PAGES );
    add_rewrite_endpoint( 'social-posts', EP_ROOT | EP_PAGES );
}
// Flush rewrite rules on plugin activation
function awce_flush_rewrite_rules() {   
    wpace_register_rewrite_endpoints();
    flush_rewrite_rules();
}


function wz_wp_head() {
    if ( strpos( $_SERVER['REQUEST_URI'], 'affiliate-area' ) === false ) {
        return;
    }

    $content = include AFFWP_CAMPAIGN_DASH_PATH . 'add-campaign.php';
    $content .= include AFFWP_CAMPAIGN_DASH_PATH . 'view-campaign.php';
    
    $creatives_content .= include AFFWP_CAMPAIGN_DASH_PATH . 'view-creatives.php';

    $escaped_content = wp_json_encode( $content );
    $escaped_creatives_content = wp_json_encode( $creatives_content );

    $custom_css       = AFFWP_CAMPAIGN_CSS_URL . 'custom.css?' . rand();
    $custom_js        = AFFWP_CAMPAIGN_JS_URL . 'custom.js?' . rand();
    $datatable_css    = AFFWP_CAMPAIGN_CSS_URL . 'datatable.css?' . rand();
    $datatable_js     = AFFWP_CAMPAIGN_JS_URL . 'datatable.js?' . rand();
    $submissions_nav_js = AFFWP_CAMPAIGN_JS_URL . 'submissions-nav.js?' . rand();
    $creatives_js = AFFWP_CAMPAIGN_JS_URL . 'creatives-nav.js?' . rand();
    $sweet_alert      = 'https://cdn.jsdelivr.net/npm/sweetalert2@11';
    $style_js         = AFFWP_CAMPAIGN_JS_URL . 'style.js?' . rand();

    $data=['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('campaign_manager_nonce')];

    ?>
    <script>
        var campaign_content = <?php echo $escaped_content; ?>;
        var creatives_content = <?php echo $escaped_creatives_content; ?>;
        var ajax_url2 = "<?php echo esc_url( admin_url('admin-ajax.php') ); ?>";
        var wp_nonce2 = "<?php echo esc_attr( wp_create_nonce('campaign_manager_nonce') ); ?>";
    </script>

    <link rel="stylesheet" href="<?php echo esc_url( $custom_css ); ?>">
    <link rel="stylesheet" href="<?php echo esc_url( $datatable_css ); ?>">
    <script src="<?php echo esc_url( $datatable_js ); ?>"></script>
    <script src="<?php echo esc_url( $sweet_alert ); ?>"></script>
    <script src="<?php echo esc_url( $submissions_nav_js ); ?>"></script>
    <script src="<?php echo esc_url( $creatives_js ); ?>"></script>
    <script src="<?php echo esc_url( $style_js ); ?>"></script>
    <script src="<?php echo esc_url( $custom_js ); ?>"></script>
    <?php
}
add_action( 'wp_head', 'wz_wp_head' );



add_action( 'init', 'wpace_register_rewrite_endpoints' );
register_activation_hook( __FILE__, 'awce_flush_rewrite_rules' );