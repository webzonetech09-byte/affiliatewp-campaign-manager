<?php

function campaign_manager_delete_campaign_type() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'affwp_campaign_types';

    // Check nonce
    if ( ! isset($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'], 'delete_campaign_type_nonce') ) {
        wp_send_json_error([ 'message' => 'Invalid nonce.' ]);
    }

    // Validate ID
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if (!$id) {
        wp_send_json_error([ 'message' => 'Invalid campaign type ID.' ]);
    }

    $deleted = $wpdb->delete($table_name, [ 'id' => $id ], [ '%d' ]);

    if ($deleted) {
        wp_send_json_success([ 'message' => 'Campaign Type deleted successfully.' ]);
    } else {
        wp_send_json_error([ 'message' => 'Failed to delete Campaign Type.' ]);
    }
}

function campaign_manager_approve_submission() {
    if ( ! isset($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'], 'campaign_manager_nonce') ) {
        wp_send_json_error(['message' => 'Invalid nonce.']);
    }
    if ( ! current_user_can('manage_options') ) {
        wp_send_json_error(['message' => 'Unauthorized.']);
    }

    global $wpdb;
    $table = $wpdb->prefix . 'affwp_shared_submission';
    $id    = intval($_POST['id']);
    $reason = sanitize_textarea_field($_POST['reason'] ?? '');

    // Get submission
    $submission = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id) );
    if ( ! $submission ) {
        wp_send_json_error(['message' => 'Submission not found.']);
    }

    $user_id = intval($submission->user_id);
    $membership_type = intval($submission->membership_type);

    // Fetch remaining daily limit
    $remaining = intval( get_user_meta( $user_id, '_wpace_remaining_limit', true ) );
    $approved  = intval( get_user_meta( $user_id, '_wpace_approved_posts' , true ) );
    if ( $remaining <= 0 ) {
        wp_send_json_error(['message' => 'User has already reached daily approval limit.']);
    }

    // Update submission status
    $updated = $wpdb->update(
        $table,
        ['status' => 'approved', 'reason' => $reason],
        ['id' => $id],
        ['%s','%s'],
        ['%d']
    );
    if ( false === $updated ) {
        wp_send_json_error(['message' => 'Database error: could not update status.']);
    }

    // Decrease remaining limit
    update_user_meta( $user_id, '_wpace_remaining_limit', max(0, $remaining - 1) );
    update_user_meta( $user_id, '_wpace_approved_posts' , max(0, $approved  + 1) );

    // (Referral creation logic unchanged below...)
    $affiliate_id = $user_id ? affwp_get_affiliate_id($user_id) : 0;
    $amount = 0;


    $amount = $wpdb->get_var( $wpdb->prepare(
            "SELECT amount_per_post FROM {$wpdb->prefix}affwp_creative_earnings_settings WHERE membership_type = %d",
            $membership_type
        ) ) ?: 0;

    $new_referral = affwp_add_referral([
        'affiliate_id' => $affiliate_id,
        'amount'       => $amount,
        'status'       => 'unpaid',
        'type'         => 'submission',
        'reference'    => $user_id,
        'description'  => $submission->title ?: 'Submission: '.$submission->link,
        'context'      => 'campaign',
        'campaign'     => $submission->campaign ?? '',
        'custom'       => maybe_serialize(['reason' => $reason]),
    ]);

    if ( $new_referral ) {
        wp_write_logs("affiliate_id $affiliate_id , Amount $amount , User: $user_id , MemberShip $membership_type");
        wp_write_logs('Refferal created with ID: '.$new_referral);
        update_post_meta($id, '_affwp_referral_id', $new_referral);
        wp_send_json_success(['message' => 'Submission approved and referral added.']);
    }

    wp_send_json_error(['message' => 'Submission approved, but referral could not be added.']);
}

function campaign_manager_reject_submission() {
    // Security check
    if ( ! isset($_POST['nonce']) || ! wp_verify_nonce( $_POST['nonce'], 'campaign_manager_nonce' ) ) {
        wp_send_json_error(['message' => 'Invalid nonce.']);
    }

    // Optional: only allow admins or managers
    if ( ! current_user_can('manage_options') ) {
        wp_send_json_error(['message' => 'Unauthorized.']);
    }

    global $wpdb;
    $table = $wpdb->prefix . 'affwp_shared_submission';
    $id    = intval($_POST['id']);
    $reason = sanitize_textarea_field($_POST['reason'] ?? '');

    // Update status to 'rejected' and store reason
    $updated = $wpdb->update(
        $table,
        [
            'status' => 'rejected',
            'reason' => $reason
        ],
        ['id' => $id],
        ['%s', '%s'], // data formats
        ['%d']        // where format
    );
    
    
    if ( false === $updated ) {
        wp_send_json_error(['message' => 'Database error: could not update status.']);
    } else {
        $referral_id = get_post_meta($id, '_affwp_referral_id', true);
        if ( $referral_id && affwp_get_referral($referral_id) ) {
            affwp_delete_referral($referral_id);
            delete_post_meta($id, '_affwp_referral_id');
            wp_write_logs("🗑️ Deleted referral ID $referral_id linked to submission ID $id by rejecting after approval submission.");
        }
        wp_send_json_success(['message' => 'Submission rejected successfully.']);
    }
}

function campaign_manager_delete_submission() {
    // Security check
    if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'campaign_manager_nonce' ) ) {
        wp_send_json_error( [ 'message' => 'Invalid nonce.' ] );
    }

    global $wpdb;
    $table = $wpdb->prefix . 'affwp_shared_submission';
    $id    = intval( $_POST['id'] );

    if ( ! $id ) {
        wp_send_json_error( [ 'message' => 'Invalid submission ID.' ] );
    }

    // Delete record
    $deleted = $wpdb->delete(
        $table,
        [ 'id' => $id ],
        [ '%d' ]
    );

    if ( false === $deleted ) {
        wp_send_json_error( [ 'message' => 'Database error: could not delete submission.' ] );
    }

    // Also delete referral if one exists
    $referral_id = get_post_meta( $id, '_affwp_referral_id', true );
    if ( $referral_id && affwp_get_referral( $referral_id ) ) {
        affwp_delete_referral( $referral_id );
        delete_post_meta( $id, '_affwp_referral_id' );
        wp_write_logs("🗑️ Deleted referral ID $referral_id linked to submission ID $id by deleting submission.");
    }

    wp_send_json_success( [ 'message' => 'Submission deleted successfully.' ] );
}

function campaign_manager_delete_campaign_rule() {
    if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'campaign_manager_nonce' ) ) {
        wp_send_json_error( [ 'message' => 'Invalid nonce.' ] );
    }

    global $wpdb;
    $table = $wpdb->prefix . 'affwp_creative_earnings_settings';
    $id    = intval( $_POST['id'] );

    if ( ! $id ) {
        wp_send_json_error( [ 'message' => 'Invalid campaign ID.' ] );
    }

    // Delete record
    $deleted = $wpdb->delete(
        $table,
        [ 'id' => $id ],
        [ '%d' ]
    );

    if ( false === $deleted ) {
        wp_send_json_error( [ 'message' => 'Database error: could not delete campaign rule.' ] );
    }

    wp_send_json_success( [ 'message' => 'Campaign deleted successfully.' ] );
}

function campaign_manager_save_campaign() {
    
    global $wpdb;
    // Security check
    if ( ! isset($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'], 'campaign_manager_nonce') ) {
        wp_send_json_error( array( 'message' => 'Invalid request.' ) );
    }

    $table_name = $wpdb->prefix . 'affwp_shared_submission'; // Change this to your real table

    $link = isset($_POST['submission_link']) ? sanitize_text_field($_POST['submission_link']) : '';
    $attachment_url = '';
    $attachment_id  = 0;

    // Handle file upload if present
    if ( !empty($_FILES['attachment']['name']) ) {
        if ( $_FILES['attachment']['error'] !== UPLOAD_ERR_OK ) {
            wp_send_json_error( array( 'message' => 'File upload error: ' . $_FILES['attachment']['error'] ) );
        }

        // Include required WordPress files
        if ( ! function_exists( 'wp_handle_upload' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
        }
        if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/image.php' );
        }
        if ( ! function_exists( 'media_handle_upload' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/media.php' );
        }

        $upload_overrides = array(
            'test_form' => false,
            'test_size' => true,
            'test_upload' => true,
        );

        $uploaded_file = wp_handle_upload( $_FILES['attachment'], $upload_overrides );
        if ( $uploaded_file && ! isset($uploaded_file['error']) ) {
            $attachment_data = array(
                'guid'           => $uploaded_file['url'], 
                'post_mime_type' => $uploaded_file['type'],
                'post_title'     => sanitize_file_name( pathinfo($_FILES['attachment']['name'], PATHINFO_FILENAME) ),
                'post_content'   => '',
                'post_status'    => 'inherit'
            );
            $attachment_id = wp_insert_attachment( $attachment_data, $uploaded_file['file'] );

            if ( ! is_wp_error($attachment_id) ) {
                $attachment_metadata = wp_generate_attachment_metadata( $attachment_id, $uploaded_file['file'] );
                wp_update_attachment_metadata( $attachment_id, $attachment_metadata );
                $attachment_url = wp_get_attachment_url( $attachment_id );
            } else {
                wp_send_json_error( array( 'message' => 'Failed to create attachment: ' . $attachment_id->get_error_message() ) );
            }
        } else {
            wp_send_json_error( array( 'message' => 'File upload failed: ' . $uploaded_file['error'] ) );
        }
    }

    // Save to database
    if ( empty($link) ) {
        wp_send_json_error( array( 'message' => 'Campaign link is required!' ) );
    }
    $order_id = get_user_meta(get_current_user_id(), 'employer_package_order_id', true);
    $package_id		 = get_post_meta($order_id, 'package_id', true);
    
    if ( function_exists( 'wc_memberships_get_user_memberships' ) ) {
        $user_id = get_current_user_id();
        $memberships = wc_memberships_get_user_memberships( $user_id );
        if ( ! empty( $memberships ) ) {
            foreach ( $memberships as $membership ) {
                if ( 'active' === $membership->get_status() ) {
                    $package_id = $membership->get_plan_id();
                    $have_membership = true;
                    break;
                }
            }
        }
    }

    $insert_data = array(
        'user_id'         => get_current_user_id(),
        'link'            => $link,
        'membership_type' => $package_id,
        'attachment'      => $attachment_url,
    );

    $result = $wpdb->insert( $table_name, $insert_data );
    if ( $result !== false ) {
        wp_send_json_success( array( 'message' => 'Campaign saved successfully!' ) );
    } else {
        wp_send_json_error( array( 'message' => 'Save failed: ' . $wpdb->last_error ) );
    }
}

function campaign_manager_update_submission() {
    global $wpdb;

    // Security check
    if ( ! isset($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'], 'campaign_manager_nonce') ) {
        wp_send_json_error( array( 'message' => 'Invalid request.' ) );
    }

    $table_name = $wpdb->prefix . 'affwp_shared_submission';

    $id   = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $link = isset($_POST['submission_link']) ? sanitize_text_field($_POST['submission_link']) : '';

    if ( empty($id) || empty($link) ) {
        wp_send_json_error( array( 'message' => 'Submission ID and Campaign link are required!' ) );
    }

    $attachment_url = '';

    // Handle file upload if present
    if ( !empty($_FILES['attachment']['name']) ) {
        if ( $_FILES['attachment']['error'] !== UPLOAD_ERR_OK ) {
            wp_send_json_error( array( 'message' => 'File upload error: ' . $_FILES['attachment']['error'] ) );
        }

        // Include required WordPress files
        if ( ! function_exists( 'wp_handle_upload' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
        }
        if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/image.php' );
        }
        if ( ! function_exists( 'media_handle_upload' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/media.php' );
        }

        $upload_overrides = array(
            'test_form' => false,
            'test_size' => true,
            'test_upload' => true,
        );

        $uploaded_file = wp_handle_upload( $_FILES['attachment'], $upload_overrides );
        if ( $uploaded_file && ! isset($uploaded_file['error']) ) {
            $attachment_data = array(
                'guid'           => $uploaded_file['url'], 
                'post_mime_type' => $uploaded_file['type'],
                'post_title'     => sanitize_file_name( pathinfo($_FILES['attachment']['name'], PATHINFO_FILENAME) ),
                'post_content'   => '',
                'post_status'    => 'inherit'
            );
            $attachment_id = wp_insert_attachment( $attachment_data, $uploaded_file['file'] );

            if ( ! is_wp_error($attachment_id) ) {
                $attachment_metadata = wp_generate_attachment_metadata( $attachment_id, $uploaded_file['file'] );
                wp_update_attachment_metadata( $attachment_id, $attachment_metadata );
                $attachment_url = wp_get_attachment_url( $attachment_id );
            } else {
                wp_send_json_error( array( 'message' => 'Failed to create attachment: ' . $attachment_id->get_error_message() ) );
            }
        } else {
            wp_send_json_error( array( 'message' => 'File upload failed: ' . $uploaded_file['error'] ) );
        }
    }

    // Build update data
    $update_data = array(
        'link' => $link
    );
    $update_format = array( '%s' );

    // Only update attachment if a new one was uploaded
    if ( ! empty( $attachment_url ) ) {
        $update_data['attachment'] = $attachment_url;
        $update_format[] = '%s';
    }

    // Perform update
    $result = $wpdb->update(
        $table_name,
        $update_data,
        array( 'id' => $id ),
        $update_format,
        array( '%d' )
    );

    if ( false === $result ) {
        wp_send_json_error( array( 'message' => 'Update failed: ' . $wpdb->last_error ) );
    } else {
        wp_send_json_success( array( 'message' => 'Submission updated successfully!' ) );
    }
}

function campaign_manager_get_creative_info() {
    
    if ( ! isset($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'], 'campaign_manager_nonce') ) {
        wp_send_json_error( array( 'message' => 'Invalid request.' ) );
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'affiliate_wp_creatives';

    $creative_id   = isset($_POST['creative_id']) ? intval($_POST['creative_id']) : 0;

    if ( empty($creative_id) || $creative_id == 0 ) {
        wp_send_json_error( array( 'message' => 'Invalid creative ID!' ) );
    }

    $creative = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$table_name} WHERE creative_id = %d", $creative_id) );
    if ( ! $creative ) {
        wp_send_json_error( array( 'message' => 'Creative not found!' ) );
    }
    wp_send_json_success( array( 'creative' => $creative , 'creative_text' => $creative->text ) );

}

function campaign_manager_update_earning_row() {
    // Security checks
    if ( ! isset($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'], 'campaign_manager_nonce') ) {
        wp_send_json_error(['message' => 'Invalid nonce.']);
    }
    if ( ! current_user_can('manage_options') ) {
        wp_send_json_error(['message' => 'Unauthorized.']);
    }
    
    global $wpdb;
    $table = $wpdb->prefix . 'affwp_creative_earnings_settings';
    
    // Sanitize inputs
    $id              = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $membership_type = isset($_POST['membership_type']) ? intval($_POST['membership_type']) : 0;
    $amount_per_post = isset($_POST['amount_per_post']) ? number_format((float) $_POST['amount_per_post'], 2, '.', '') : '0.00';
    $posts_per_day   = isset($_POST['posts_per_day']) ? intval($_POST['posts_per_day']) : 0;
    
    // update_user_meta( 70 , "_wpace_remaining_limit" , 4 );
    // update_user_meta( 143 , "_wpace_remaining_limit" , 4 );
    // update_user_meta( 145 , "_wpace_remaining_limit" , 4 );
    // update_user_meta( 146 , "_wpace_remaining_limit" , 0 );
    // update_user_meta( 144 , "_wpace_remaining_limit" , 0 );

    // Check if the row exists
    $existing_row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id));
    if (!$existing_row) {
        wp_send_json_error(['message' => 'Row with ID ' . $id . ' not found.']);
    }

    if( isset ( $_POST['limits_apply'] ) && $_POST['limits_apply'] == 1 ) {

        $old_limit = $existing_row->posts_per_day;
        $new_limit = $posts_per_day;

        $table_name = $wpdb->prefix . 'affwp_shared_submission';

        // Get unique user IDs only
        $user_ids = $wpdb->get_col( "SELECT DISTINCT user_id FROM $table_name" );

        foreach ( $user_ids as $user_id ) {

            $user_id   = intval( $user_id );
            $remaining = intval( get_user_meta( $user_id, '_wpace_remaining_limit' , true ) );
            $approved  = intval( get_user_meta( $user_id, '_wpace_approved_posts'  , true ) );

            if ( $old_limit > $new_limit ) {
                $updated_limit = $remaining - ( $old_limit - $new_limit );
            } elseif ( $new_limit > $old_limit ) {
                $updated_limit = $remaining + ( $new_limit - $old_limit );
            } else {
                $updated_limit = $remaining;
            }
            $updated_limit = $new_limit-$approved;

            update_user_meta( $user_id, '_wpace_remaining_limit' , $updated_limit );

            wp_write_logs( "Calculating limits for User: $user_id , Remaining: $remaining , Approved: $approved , Old Limits: $old_limit , New Limit: $new_limit , Updated Limit: $updated_limit" );
        }

    } 

    // Get membership title
    $product         = $membership_type ? get_post($membership_type) : null;
    $membership_name = $product ? sanitize_text_field($product->post_title) : '--';
    
    // Update row with proper data types
    $updated = $wpdb->update(
        $table,
        [
            'membership_type' => $membership_type,
            'amount_per_post' => $amount_per_post,
            'posts_per_day'   => $posts_per_day,
        ],
        ['id' => $id],
        ['%d','%s','%d'], // Changed %f to %s for decimal field
        ['%d']
    );
    
    // Debug: Check for database errors
    if ($wpdb->last_error) {
        wp_write_logs('Database Error: ' . $wpdb->last_error);
        wp_send_json_error(['message' => 'Database error: ' . $wpdb->last_error]);
    }
    
    // Debug: Log the result
    wp_write_logs('Update result: ' . print_r($updated, true));
    
    if ( false === $updated ) {
        wp_send_json_error(['message' => 'Database error: could not update row.']);
    }
    
    wp_send_json_success([
        'message'           => "<b>{$membership_name}</b> membership updated successfully.",
        'table'             => $table,
        'membership'        => $membership_name,
        'amount_per_post'   => $amount_per_post,
        'posts_per_day'     => $posts_per_day,
        'rows_affected'     => $updated
    ]);
}

$actions = [
    'approve_submission'    => 'campaign_manager_approve_submission',
    'update_earning_row'    => 'campaign_manager_update_earning_row',
    'get_creative_info'     => 'campaign_manager_get_creative_info',
    'reject_submission'     => 'campaign_manager_reject_submission',
    'delete_submission'     => 'campaign_manager_delete_submission',
    'delete_campaign_rule'  => 'campaign_manager_delete_campaign_rule',
    'delete_campaign_type'  => 'campaign_manager_delete_campaign_type',
    'update_submission'     => 'campaign_manager_update_submission',
    'save_campaign'         => 'campaign_manager_save_campaign',
];

foreach ($actions as $action => $callback) {
    add_action('wp_ajax_' . $action, $callback); // Admin side
    add_action('wp_ajax_nopriv_' . $action, $callback); // Front end (non-logged-in users)
}