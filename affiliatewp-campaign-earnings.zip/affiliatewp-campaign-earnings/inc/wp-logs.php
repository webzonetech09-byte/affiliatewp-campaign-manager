<?php
if (!function_exists('wp_clear_logs')) {
    function wp_clear_logs() {
        $last_clear = get_option('wp_last_clear_time');
        if (!$last_clear) {
            update_option('wp_last_clear_time', time());
        } else {
            $current_time = time();
            if (($current_time - $last_clear) >= 6 * HOUR_IN_SECONDS) {
                file_put_contents(WP_LOGS_FILE, "Plugin logs cleared on " . date('Y-m-d H:i:s') . "\n", LOCK_EX);
                update_option('wp_last_clear_time', $current_time);
            }
        }
    }
}
if (!function_exists('wp_write_logs')) {
    function wp_write_logs($message) {
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "$message $timestamp\n";
        file_put_contents(WP_LOGS_FILE, $log_entry, FILE_APPEND);
    }
}
if (!function_exists('wp_display_logs')) {
    function wp_display_logs() {
        $wp_logs = '';
        if (file_exists(WP_LOGS_FILE) && filesize(WP_LOGS_FILE) > 0) {
            $wp_logs .= '<div class="wz-logs-conwpner">';
            $wp_logs .= nl2br(file_get_contents(WP_LOGS_FILE)); // Convert newlines to <br> for display
            $wp_logs .= '</div>'; // Properly close the div
        } else {
            // If no logs available, show a message
            $wp_logs .= 'No logs available.';
        }
        return $wp_logs;
    }
}
add_action('init', function() {
    if (function_exists('wp_display_logs') && isset($_GET['display_logs'])) {
        $wz_logs = wp_display_logs();
        echo "<pre>";
        print_r($wz_logs);
        echo "</pre>";
        exit;
    }
    if (function_exists('wp_clear_logs') && isset($_GET['clear_logs'])) {
        file_put_contents(WP_LOGS_FILE, "Plugin logs cleared on " . date('Y-m-d H:i:s') . "\n", LOCK_EX);
        update_option('wp_last_clear_time', $current_time);
        $wz_logs = wp_display_logs();
        echo "<pre>";
            print_r($wz_logs);
        echo "</pre>";
        exit;
    }
});
?>