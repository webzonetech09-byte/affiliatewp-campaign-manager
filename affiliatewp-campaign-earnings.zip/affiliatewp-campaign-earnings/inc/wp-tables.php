<?php
// Update the ace_create_wp_tables function in wp-tables.php
function ace_create_wp_tables() {
    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $charset_collate = $wpdb->get_charset_collate();

    $tables = [

        // 1️⃣ Campaign Types
        'affwp_campaign_types' => "
            CREATE TABLE %s (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                type_name varchar(100) NOT NULL,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $charset_collate;
        ",

        // 2️⃣ Social Buzz Rules
        'affwp_social_buzz_rules' => "
            CREATE TABLE %s (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                membership_type varchar(100) NOT NULL,
                campaigns_allowed int(11) NOT NULL DEFAULT 0,
                shares_allowed int(11) NOT NULL DEFAULT 0,
                campaign_types text,
                PRIMARY KEY (id)
            ) $charset_collate;
        ",

        // 3️⃣ Shared Submissions
        'affwp_shared_submission' => "
            CREATE TABLE %s (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) NOT NULL,
                membership_type varchar(100) NOT NULL,
                link text NOT NULL,
                status varchar(20) NOT NULL DEFAULT 'pending',
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $charset_collate;
        ",

        // 4️⃣ Creative Earnings Settings
        'affwp_creative_earnings_settings' => "
            CREATE TABLE %s (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                campaign_type varchar(100) NOT NULL,
                membership_type varchar(100) NOT NULL,
                posts_per_day int(11) NOT NULL DEFAULT 0,
                amount_per_post decimal(10,2) NOT NULL DEFAULT 0.00,
                limits_apply tinyint(1) NOT NULL DEFAULT 0,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $charset_collate;
        "
    ];

    foreach ($tables as $table_name => $sql) {

        $full_table_name = $wpdb->prefix . $table_name;

        $formatted_sql = sprintf($sql, $full_table_name);

        dbDelta($formatted_sql);
    }
}

add_action('plugins_loaded', function() {
    // global $wpdb;
    // $tables = [
    //     $wpdb->prefix . 'affwp_creative_earnings_settings',
    //     $wpdb->prefix . 'affwp_shared_submission',
    // ];
    // foreach ( $tables as $table ) {
    //     $wpdb->query( "DROP TABLE IF EXISTS `$table`" );
    // }

    // ace_create_wp_tables();
});