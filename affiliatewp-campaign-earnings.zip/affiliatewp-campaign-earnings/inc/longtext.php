<?php
/**
 * Add Long Text Creative Type to AffiliateWP - Working Version
 */

// Let's hook into the function directly and see what filters it uses
add_action( 'init', function() {
    // Check what's inside the affwp_get_creative_types function
    if ( function_exists( 'affwp_get_creative_types' ) ) {
        // Let's try to intercept the function call
        add_filter( 'affwp_get_creative_types', function( $types ) {
            // wp_write_logs( 'affwp_get_creative_types filter called: ' . print_r( $types, true ) );
            $types['long_text'] = 'Long Text';
            return $types;
        }, 10, 1 );
    }
});

// Try hooking into the admin page directly
add_action( 'affwp_creatives_page_add_new', function() {
    // wp_write_logs( 'On add new creatives page' );
});

// Try a different approach - hook into WordPress admin
add_action( 'admin_enqueue_scripts', function( $hook ) {
    if ( strpos( $hook, 'creative' ) !== false ) {
        // wp_write_logs( 'Admin script hook: ' . $hook );
        
        // Try to modify the types here
        add_filter( 'affwp_get_creative_types', function( $types ) {
            // wp_write_logs( 'Modifying types in admin_enqueue_scripts' );
            $types['long_text'] = 'Long Text';
            return $types;
        });
    }
});

// Let's also try the class method approach
add_action( 'init', function() {
    if ( class_exists( 'Affiliate_WP_Creatives' ) ) {
        // Try to find the method that gets creative types
        $creatives = new Affiliate_WP_Creatives();
        $methods = get_class_methods( $creatives );
        // wp_write_logs( 'Creatives class methods: ' . print_r( $methods, true ) );
    }
});