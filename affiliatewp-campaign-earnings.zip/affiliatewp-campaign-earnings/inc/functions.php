<?php

    function ace_wp_datatable() {
        wp_enqueue_style( 'ace-datatable-css', AFFWP_CAMPAIGN_CSS_URL.'datatable.css?'.rand(0,9999), [], '1.13.6' );
        wp_enqueue_script( 'ace-datatable-js', AFFWP_CAMPAIGN_JS_URL.'datatable.js?'.rand(0,9999), [ 'jquery' ], '1.13.6', true );
    }

    function ace_admin_enqueue_scripts($hook){
        ace_wp_datatable();
        wp_enqueue_style('ace-admin-css', AFFWP_CAMPAIGN_CSS_URL.'admin.css?'.rand(),[],null);
        wp_enqueue_script('sweetalert','https://cdn.jsdelivr.net/npm/sweetalert2@11',[],null,true);
        wp_enqueue_script('campaign-manager-admin',AFFWP_CAMPAIGN_JS_URL.'admin.js?'.rand(),['jquery','sweetalert'],null,true);
        wp_enqueue_script('campaign-manager-custom',AFFWP_CAMPAIGN_JS_URL.'custom.js?'.rand(),['jquery','sweetalert'],null,true);

        $data=['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('campaign_manager_nonce')];
        wp_localize_script('campaign-manager-admin','campaignManager',$data);
        wp_localize_script('campaign-manager-custom','campaignManager',$data);

        wp_enqueue_style('ace-custom-css',AFFWP_CAMPAIGN_CSS_URL.'custom.css?'.rand(),[],null);
    }

    function ace_wp_enqueue_scripts(){
        wp_enqueue_style('ace-custom-css',AFFWP_CAMPAIGN_CSS_URL.'custom.css?'.rand(),[],null);
        wp_enqueue_script('sweetalert','https://cdn.jsdelivr.net/npm/sweetalert2@11',[],null,true);
        ace_wp_datatable();
        wp_enqueue_script('campaign-manager-custom',AFFWP_CAMPAIGN_JS_URL.'custom.js?'.rand(),['jquery','sweetalert'],null,true);
        wp_enqueue_script('campaign-manager-style',AFFWP_CAMPAIGN_JS_URL.'style.js?'.rand(),['jquery','sweetalert'],null,true);

        $data=['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('campaign_manager_nonce')];
        wp_localize_script('campaign-manager-custom','campaignManager',$data);
        wp_localize_script('campaign-manager-style','campaignManager',$data);
    }
// 
    function get_membership_plans_by_product_id( $product_id ) {
        $args = array(
            'post_type'  => 'wc_membership_plan',
            'posts_per_page' => 1,
            'post_status' => 'any',
            'meta_query' => array(
                array(
                    'key'     => '_product_ids',
                    'value'   => $product_id,
                    'compare' => 'LIKE',
                ),
            ),
        );

        $plans = get_posts( $args );
        if( empty($plans) ) {
            return $product_id;
        }
        return $plans[0]->ID;
    }

    // Create a shortcode to show membership plans dropdown
    function myplugin_membership_plans_dropdown_shortcode( $atts ) {
        $atts = shortcode_atts( array(
            'name' => 'membership_plan', // default field name
        ), $atts, 'membership_dropdown' );

        // Query membership plans
        $args = array(
            'post_type'      => 'wc_membership_plan',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'orderby'        => 'title',
            'order'          => 'ASC',
        );

        $plans = get_posts( $args );

        ob_start();

        if ( ! empty( $plans ) ) {
            ?>
                <?php foreach ( $plans as $plan ) : ?>
                    <option value="<?php echo esc_attr( $plan->ID ); ?>">
                        <?php echo esc_html( $plan->post_title ); ?>
                    </option>
                <?php endforeach; ?>
            <?php
        }

        return ob_get_clean();
    }

    function render_creative_earnings_add() {
        require_once( AFFWP_CAMPAIGN_ADMIN_PATH.'add-creative.php' );
    }

    function render_campaign_dashboard() {
        require_once( AFFWP_CAMPAIGN_ADMIN_PATH.'dashboard.php' );
    }

    function wp_creative_posts_orignal( $creative ) {
        $id = esc_attr( $creative->creative_id );
        $name = esc_html( $creative->name ?? 'Fameidols' );
        $description = esc_html( $creative->description ?? '' );
        $title = $text = esc_html( $creative->text ?? $name );
        $url = esc_url( $creative->url ?? '#' );
        $ref_link = esc_url( $creative->url ?? '#' );
        $image = esc_url( $creative->image ?? '' );
        $type = esc_html( $creative->type ?? 'text_link' );
        include( AFFWP_CAMPAIGN_DASH_PATH.'creative-posts.php' );
    }
    
    function wp_creative_social_posts( $creative ) {
        $id = esc_attr( $creative->creative_id );
        $name = esc_html( $creative->name ?? 'Fameidols' );
        $description = esc_html( $creative->description ?? '' );
        $text = esc_html( $creative->text ?? $name );
        $url = esc_url( $creative->url ?? '#' );
        $ref_link = esc_url( $creative->url ?? '#' );
        $image = esc_url( $creative->image ?? '' );
        include( AFFWP_CAMPAIGN_DASH_PATH.'social-posts.php' );
    }

    function wp_creative_social_posts2( $creative ) {
        $id = esc_attr( $creative->creative_id );
        $name = esc_html( $creative->name ?? 'Fameidols' );
        $description = esc_html( $creative->description ?? '' );
        $text = esc_html( $creative->text ?? $name );
        $url = esc_url( $creative->url ?? '#' );
        $ref_link = esc_url( $creative->url ?? '#' );
        $image = esc_url( $creative->image ?? '' );
        include( AFFWP_CAMPAIGN_DASH_PATH.'social-posts2.php' );
    }
    

    function wpace_check_user_limits() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'affwp_shared_submission';
        $settings_table = $wpdb->prefix . 'affwp_creative_earnings_settings';

        // Get distinct users with membership_type
        $user_rows = $wpdb->get_results( "SELECT DISTINCT user_id, membership_type FROM $table_name" );

        $today = current_time( 'Y-m-d' ); // WP-safe current date

        foreach ( $user_rows as $row ) {
            $user_id   = intval( $row->user_id );
            $membership_id = get_membership_plans_by_product_id( $row->membership_type );
            $membership_setting = $wpdb->get_row( $wpdb->prepare("SELECT * FROM $settings_table WHERE membership_type = %d", $membership_id) );
            $membership_limit = $membership_setting ? intval( $membership_setting->posts_per_day ) : 0;
            
            $meta_key  = '_wpace_remaining_limit';
            $date_key  = $meta_key . '_date'; // store last reset date separately

            $last_date = get_user_meta( $user_id, $date_key, true );

            // Reset only if not updated today
            if ( $last_date !== $today ) {
                wp_write_logs( "Resetting limit for user $user_id, membership {$membership_id} , Limit $membership_limit " );
                update_user_meta( $user_id, $date_key, $today );
                update_user_meta( $user_id, $meta_key, $membership_limit );
                update_user_meta( $user_id, '_wpace_approved_posts', 0 );
            // }else{
            //     wp_write_logs( "Limit for user $user_id, membership {$membership_id} already reset today." );
            }
        }
    }

    function render_user_submissions_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'affwp_shared_submission';
    
        // Check if table exists
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) !== $table_name ) {
            echo '<div class="error"><p>Table not found: ' . esc_html($table_name) . '</p></div>';
            return;
        }

        wpace_check_user_limits();
       // Fetch ASCENDING to show latest at the bottom
        $rows = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id ASC");
        
        ?>
        <div class="wrap">
            <h2 class="table-title" style="display:none;">Membership Applications</h2>
            <?php require_once( AFFWP_CAMPAIGN_ADMIN_PATH . 'user-membership.php' ); ?>
        </div>
        <?php
    }
    
    function render_creative_earnings_view( ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'affwp_creative_earnings_settings';

        // Check if table exists
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) !== $table_name ) {
            echo '<div class="error"><p>Table not found: ' . esc_html($table_name) . '</p></div>';
            return;
        }

        // Fetch saved rules
        $rows = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");

        ?>
        <div class="wrap">
            <?php
                require_once( AFFWP_CAMPAIGN_ADMIN_PATH.'creative-table.php' );
            ?>
        </div>
        <?php
    }

    function render_campaign_types_settings(){

        echo '<div class="wrap"><h1>Campaign Types</h1></div>'; 
        require_once AFFWP_CAMPAIGN_ADMIN_PATH . 'campaign-types-settings.php';
    }

    // Boilerplate for remaining new pages
    function render_social_buzz_rules() { 
        echo '<div class="wrap"><h1>Social Buzz Rules</h1></div>'; 
        require_once AFFWP_CAMPAIGN_ADMIN_PATH . 'social-buzz-rules.php';
    }
    function render_employer_submissions() { 
        echo '<div class="wrap"><h1>Employer Submissions</h1></div>'; 
        require_once AFFWP_CAMPAIGN_ADMIN_PATH . 'employer-submissions.php';
    }
    function render_employer_settings() { 
        echo '<div class="wrap"><h1>Employer Settings</h1></div>'; 
        require_once AFFWP_CAMPAIGN_ADMIN_PATH . 'employer-settings.php';
    }
    function render_freelancer_settings() { 
        echo '<div class="wrap"><h1>Freelancer Settings</h1></div>'; 
        require_once AFFWP_CAMPAIGN_ADMIN_PATH . 'freelancer-settings.php';
    }
    function render_extra_settings() { 
        echo '<div class="wrap"><h1>Extra Settings</h1></div>'; 
        require_once AFFWP_CAMPAIGN_ADMIN_PATH . 'extra-settings.php';
    }


    function wp_add_campaign_data_callback() {
        echo require_once( AFFWP_CAMPAIGN_DASH_PATH.'add-campaign.php' );
        echo require_once( AFFWP_CAMPAIGN_DASH_PATH.'view-campaign.php' );
    }

    function wp_custom_affwp_update_creative( array $data = array() ) : bool {
    
        // Validate creative ID
        if ( empty( $data['creative_id'] ) || ! $creative = affwp_get_creative( $data['creative_id'] ) ) {
            wp_write_logs( 'Invalid or missing creative ID' );
            return false;
        }
    
        // Determine type
        $type = $data['type'] ?? '';
        if ( ! empty( $data['social_post_checkbox'] ) ) {
            $type = 'social_post';
        }
    
        wp_write_logs( "Updated {$creative->ID} Creative Type: {$type}" );
        // wp_write_logs( 'Creative Text: ' . ($data['text'] ?? '') );
        // wp_write_logs( 'Creative Data: ' . print_r( $data, true ) );
    
        // Prepare arguments
        $args = array(
            'name'          => ! empty( $data['name'] ) ? sanitize_text_field( $data['name'] ) : __( 'Creative', 'affiliate-wp' ),
            'description'   => ! empty( $data['description'] ) ? wp_kses_post( $data['description'] ) : '',
            'url'           => ! empty( $data['url'] ) ? esc_url_raw( $data['url'] ) : get_site_url(),
            'text'          => $data['text'] ?? '',
            'image'         => ( $type === 'image' && ! empty( $data['image'] ) ) ? esc_url( $data['image'] ) : '',
            'attachment_id' => ( $type === 'image' && ! empty( $data['image'] ) ) ? attachment_url_to_postid( esc_url( $data['image'] ) ) : 0,
            'type'          => $type,
            'status'        => ! empty( $data['status'] ) ? sanitize_text_field( $data['status'] ) : '',
            'date_updated'  => gmdate( 'Y-m-d H:i:s' ),
            'notes'         => ! empty( $data['notes'] ) ? wp_kses_post( $data['notes'] ) : '',
            'start_date'    => ! empty( $data['start_date'] ) && false === affwp_is_upgrade_required( 'pro' ) ? gmdate( 'Y-m-d H:i:s', strtotime( $data['start_date'] ) ) : '',
            'end_date'      => ! empty( $data['end_date'] ) && false === affwp_is_upgrade_required( 'pro' ) ? gmdate( 'Y-m-d H:i:s', strtotime( $data['end_date'] ) ) : '',
        );
    
        // Append QR Code metadata if type is qr_code
        if ( $type === 'qr_code' ) {
            $args = array_merge( $args, array(
                'qrcode_code_color' => $data['qrcode_code_color'] ?? '',
                'qrcode_bg_color'   => $data['qrcode_bg_color'] ?? '',
            ));
        }
    
        // Determine scheduled status
        $args['status'] = affwp_determine_schedule_status( $args['status'], $args['start_date'], $args['end_date'] );
    
        // Update creative
        if ( affiliate_wp()->creatives->update( $creative->ID, $args, '', 'creative' ) ) {
            return true;
        }
    
        return false;
    }

    function wp_custom_affwp_process_update_creative( $data ) {
        if ( ! is_admin() ) {
            wp_write_logs( 'Not in admin area' );
            return false;
        }
    
        if ( ! current_user_can( 'manage_creatives' ) ) {
            wp_write_logs( 'User does not have permission to manage creatives' );
            wp_die( __( 'You do not have permission to manage creatives', 'affiliate-wp' ), __( 'Error', 'affiliate-wp' ), array( 'response' => 403 ) );
        }
    
        if ( wp_custom_affwp_update_creative( $data ) ) {
            wp_write_logs( 'Creative updated successfully: ' . print_r( $data, true ) );
            wp_write_logs( "Data Type: ".$data['type'] );
            // Update QR Code colors if is QR Code type, otherwise delete meta.
            if ( 'qr_code' === $data['type'] ) {
    
                if ( isset( $data['qrcode_code_color'], $data['qrcode_bg_color'] ) ) {
    
                    affwp_save_qrcode_colors(
                        $data['creative_id'],
                        $data['qrcode_code_color'],
                        $data['qrcode_bg_color']
                    );
                }
            } else {
                affiliatewp_delete_creative_meta( $data['creative_id'], 'qrcode_code_color' );
                affiliatewp_delete_creative_meta( $data['creative_id'], 'qrcode_bg_color' );
            }
    
            wp_safe_redirect( affwp_admin_url( 'creatives', array( 'action' => 'edit_creative', 'affwp_notice' => 'creative_updated', 'creative_id' => $data['creative_id'] ) ) );
            exit;
        } else {
            wp_write_logs( 'Failed to update creative: ' . print_r( $data, true ) );
            wp_safe_redirect( affwp_admin_url( 'creatives', array( 'action' => 'edit_creative', 'affwp_notice' => 'creative_update_failed' ) ) );
            exit;
        }
    
    }

    function wp_custom_affwp_process_add_creative( $data ) {
    
        if ( ! is_admin() ) {
            return false;
        }
    
        if ( ! current_user_can( 'manage_creatives' ) ) {
            wp_die( __( 'You do not have permission to manage creatives', 'affiliate-wp' ), __( 'Error', 'affiliate-wp' ), array( 'response' => 403 ) );
        }
    
        if ( wp_custom_affwp_add_creative( $data ) ) {
            wp_safe_redirect( affwp_admin_url( 'creatives', array( 'affwp_notice' => 'creative_added' ) ) );
            exit;
        } else {
            wp_safe_redirect( affwp_admin_url( 'creatives', array( 'affwp_notice' => 'creative_added_failed' ) ) );
            exit;
        }
    
    }

    function wp_custom_affwp_add_creative( array $data = array() ) {
    
        $type = $data['type'];
        if( $data['social_post_checkbox'] ) $type = 'social_post';
        wp_write_logs( "New Creative Type: ".$type );
        wp_write_logs( 'Creative Data: ' . print_r( $data, true ) );
    
        $args = array(
            'name'        => ! empty( $data['name'] ) ? sanitize_text_field( $data['name'] ) : __( 'Creative', 'affiliate-wp' ),
            'description' => ! empty( $data['description'] ) ? wp_kses_post( $data['description'] ) : '',
            'url'         => ! empty( $data['url'] ) ? esc_url_raw( $data['url'] ) : get_site_url(),
            'text'        => ! empty( $data['text'] ) ? $data['text'] : get_bloginfo( 'name' ),
            'image'       => isset( $data['type'] ) && 'image' === $data['type'] && ! empty( $data['image'] )
                ? esc_url( $data['image'] )
                : '',
            'type'        => $type,
            'status'      => ! empty( $data['status'] ) ? sanitize_text_field( $data['status'] ) : '',
            'date'        => ! empty( $data['date'] ) ? $data['date'] : '',
            'notes'       => ! empty( $data['notes'] ) ? wp_kses_post( $data['notes'] ) : '',
            'start_date'  => ! empty( $data['start_date'] ) && false === affwp_is_upgrade_required( 'pro' ) ? gmdate( 'Y-m-d H:i:s', strtotime( $data['start_date'] ) ) : '',
            'end_date'    => ! empty( $data['end_date'] ) && false === affwp_is_upgrade_required( 'pro' ) ? gmdate( 'Y-m-d H:i:s', strtotime( $data['end_date'] ) ) : '',
        );
    
        // Append the QR Code colors data to be saved as metadata after inserting the creative.
        if ( 'qr_code' === $args['type'] ) {
    
            $args = array_merge(
                $args,
                array(
                    'qrcode_code_color' => $data['qrcode_code_color'] ?? '',
                    'qrcode_bg_color'   => $data['qrcode_bg_color'] ?? '',
                )
            );
        }
    
        // Check the start and end dates and maybe change the status.
        $args['status'] = affwp_determine_schedule_status( $args['status'], $args['start_date'], $args['end_date'] );
    
        if ( $creative_id = affiliate_wp()->creatives->add( $args ) ) {
            return $creative_id;
        }
    
        return false;
    }

    function my_link_referral_to_affiliate( $order_id ) {
        global $wpdb;
        if ( ! function_exists( 'affwp_get_affiliate_id' ) ) {
            wp_write_logs( "AffiliateWP not active, returning" );
            return;
        }
        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            wp_write_logs( "Order not found for ID: $order_id" );
            return;
        }
        $user_id = $order->get_user_id();
        if ( ! $user_id ) {
            wp_write_logs( "No user ID found for order: $order_id" );
            return;
        }
        $affiliate_id = affwp_get_affiliate_id( $user_id );
        if ( ! $affiliate_id ) {
            wp_write_logs( "No affiliate found for user $user_id, creating new affiliate" );
            $affiliate_id = affwp_add_affiliate( [
                'user_id' => $user_id,
                'status'  => 'active'
            ] );
        }
        if ( ! $affiliate_id ) {
            wp_write_logs( "Affiliate creation failed for user $user_id" );
            return;
        }
        $affiliate = $wpdb->get_var( $wpdb->prepare(
            "SELECT user_id 
             FROM {$wpdb->prefix}affiliate_wp_affiliates  
             WHERE affiliate_id = %d 
             LIMIT 1",
            $affiliate_id
        ) );

        $reffer_by = 0;
        $customer = affiliate_wp()->customers->get_by( 'user_id', $affiliate );
        if ( $customer ) {
            $lifetime_customer = affiliate_wp_lifetime_commissions()->lifetime_customers->get_by( 'affwp_customer_id', $customer->customer_id );
            if ( $lifetime_customer ) {
                $linked_affiliate = affwp_get_affiliate( $lifetime_customer->affiliate_id );
                if ( false !== $linked_affiliate ) $reffer_by = $linked_affiliate->ID;
            }
        }

        wp_write_logs( "$affiliate_id Affiliate ID: $reffer_by" );
        $calculated_total = 0;
        $descriptions     = [];
        foreach ( $order->get_items() as $item ) {
            $product_id   = $item->get_product_id();
            $product_name = $item->get_name();
            $line_total   = (float) $item->get_total();
            $product_rate_type = get_post_meta( $product_id, '_affwp_woocommerce_product_rate_type', true );
            $product_rate      = get_post_meta( $product_id, '_affwp_woocommerce_product_rate', true );
            wp_write_logs( "Product: $product_name | ID: $product_id | line_total: $line_total | rate_type: $product_rate_type | rate: $product_rate" );
            if ( $product_rate && $product_rate_type ) {
                if ( 'flat' === strtolower( $product_rate_type ) || 'flat_usd' === strtolower( $product_rate_type ) ) {
                    $commission = (float) $product_rate;
                    wp_write_logs( "Flat rate applied: $commission" );
                } else {
                    $commission = ( (float) $product_rate / 100 ) * $line_total;
                    wp_write_logs( "Percentage rate applied: ($product_rate / 100) * $line_total = $commission" );
                }
            } else {
                $commission = 0.10 * $line_total;
                wp_write_logs( "Default 10% rate applied: $commission" );
            }
            $calculated_total += $commission;
            $descriptions[]    = $product_name;
        }
        $description_text = implode( ', ', $descriptions );
        $description_text = $description_text;
        wp_write_logs( "Total calculated commission: $calculated_total | Description: $description_text" );
        $existing_referral = affiliate_wp()->referrals->get_by( 'reference', $order_id );
        if ( $existing_referral ) {
            wp_write_logs( "Updating existing referral ID: {$existing_referral->referral_id}" );
            affwp_update_referral( $existing_referral->referral_id, [
                'amount'      => $calculated_total,
                'affiliate_id' => $reffer_by,
                'description' => $description_text,
                'status'      => 'pending'
            ] );
        } else {
            $new_referral_id = affwp_add_referral( [
                'affiliate_id' => $reffer_by,
                'amount'       => $calculated_total,
                'reference'    => $order_id,
                'context'      => 'woocommerce',
                'description'  => $description_text,
                'status'       => 'pending'
            ] );
            wp_write_logs( "New referral created with ID: $new_referral_id" );
        }
    }


add_action( 'init', function() {
    if ( isset($_GET['test_r']) ) {
        global $wpdb;
        
		$customer = affiliate_wp()->customers->get_by( 'user_id', 128 );
        if ( $customer ) {
            $lifetime_customer = affiliate_wp_lifetime_commissions()->lifetime_customers->get_by( 'affwp_customer_id', $customer->customer_id );
            if ( $lifetime_customer ) {
                $linked_affiliate = affwp_get_affiliate( $lifetime_customer->affiliate_id );
                if ( false !== $linked_affiliate ) $reffer_by = $linked_affiliate->ID;
            }
        }

        exit;
    }
});


function ace_add_column_if_not_exists( $table_name, $column_name, $column_definition ) {
    global $wpdb;

    $full_table = $wpdb->prefix . $table_name;

    // Check if table exists
    if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $full_table ) ) !== $full_table ) {
        return false;
    }

    // Check if column exists
    $column = $wpdb->get_results( "SHOW COLUMNS FROM `$full_table` LIKE '$column_name'" );

    if ( empty( $column ) ) {

        $wpdb->query( "ALTER TABLE `$full_table` ADD `$column_name` $column_definition" );

        return true; // Column added
    }

    return false; // Already exists
}